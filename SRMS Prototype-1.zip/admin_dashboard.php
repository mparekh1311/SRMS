<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get schools
$schoolsQuery = "SELECT * FROM School ORDER BY school_name";
$schoolsResult = $conn->query($schoolsQuery);
$schools = [];
while ($row = $schoolsResult->fetch_assoc()) {
    $schools[$row['school_id']] = $row;
}

// Get students count
$studentsQuery = "SELECT COUNT(*) as count FROM Student";
$studentsResult = $conn->query($studentsQuery);
$studentCount = $studentsResult->fetch_assoc()['count'];

// Get teachers count
$teachersQuery = "SELECT COUNT(*) as count FROM Teacher";
$teachersResult = $conn->query($teachersQuery);
$teacherCount = $teachersResult->fetch_assoc()['count'];

// Get classes count
$classesQuery = "SELECT COUNT(*) as count FROM Class";
$classesResult = $conn->query($classesQuery);
$classCount = $classesResult->fetch_assoc()['count'];

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .welcome-banner {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            text-align: center;
        }
        .stat-value {
            font-size: 2.5rem;
            font-weight: 600;
            color: #2563eb;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            color: #6b7280;
        }
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #1e40af;
        }
        .btn-secondary {
            background: #6b7280;
        }
        .btn-secondary:hover {
            background: #4b5563;
        }
        .schools-table {
            width: 100%;
            border-collapse: collapse;
        }
        .schools-table th, .schools-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .schools-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .action-link {
            color: #2563eb;
            text-decoration: none;
            margin-right: 1rem;
        }
        .action-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>Manage schools in the Student Result Management System.</p>
        </div>

        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-value"><?php echo $studentCount; ?></div>
                <div class="stat-label">Students</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $teacherCount; ?></div>
                <div class="stat-label">Teachers</div>
            </div>
           
            <div class="stat-card">
                <div class="stat-value"><?php echo count($schools); ?></div>
                <div class="stat-label">Schools</div>
            </div>
        </div>

        <div class="action-buttons">
            <a href="manage_school.php" color="#2563eb" class="btn btn-secondary">Add New School</a>
        </div>

        <div class="card">
            <h2>Schools</h2>
            <table class="schools-table">
                <thead>
                    <tr>
                        <th>School Name</th>
                        <th>Address</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($schools as $school): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($school['school_name']); ?></td>
                            <td><?php echo htmlspecialchars($school['school_address']); ?></td>
                            <td>
                                <a href="manage_school.php?id=<?php echo $school['school_id']; ?>" class="action-link">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>