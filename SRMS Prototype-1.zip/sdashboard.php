<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in as student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: login.php");
    exit();
}

// Get student information
$studentId = 0;
$query = "SELECT s.student_id, s.roll_number, c.class_id, c.class_name, c.division, sc.school_name 
          FROM Student s 
          JOIN Class c ON s.class_id = c.class_id 
          JOIN School sc ON s.school_id = sc.school_id 
          WHERE s.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $studentData = $result->fetch_assoc();
    $studentId = $studentData['student_id'];
    $classId = $studentData['class_id'];
} else {
    // Redirect if student data not found
    header("Location: login.php");
    exit();
}

// Get student results
$resultsQuery = "
    SELECT r.*, s.subject_name
    FROM Result r
    JOIN Subject s ON r.subject_id = s.subject_id
    WHERE r.student_id = ?
    ORDER BY s.subject_name, r.exam_term
";
$stmt = $conn->prepare($resultsQuery);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$resultsResult = $stmt->get_result();

$studentResults = [];
while ($row = $resultsResult->fetch_assoc()) {
    $subjectId = $row['subject_id'];
    $examTerm = $row['exam_term'];
    
    if (!isset($studentResults[$subjectId])) {
        $studentResults[$subjectId] = [
            'subject_name' => $row['subject_name'],
            'terms' => []
        ];
    }
    
    $studentResults[$subjectId]['terms'][$examTerm] = [
        'marks_obtained' => $row['marks_obtained'],
        'total_marks' => $row['total_subject_marks'],
        'percentage' => ($row['marks_obtained'] / $row['total_subject_marks']) * 100
    ];
}

// Calculate overall statistics
$totalMarks = 0;
$totalMaxMarks = 0;
$subjectCount = 0;

$termAverages = [
    'term1' => ['total' => 0, 'count' => 0],
    'term2' => ['total' => 0, 'count' => 0]
];

foreach ($studentResults as $subjectId => $subjectData) {
    foreach ($subjectData['terms'] as $term => $termData) {
        $totalMarks += $termData['marks_obtained'];
        $totalMaxMarks += $termData['total_marks'];
        $subjectCount++;
        
        $termAverages[$term]['total'] += $termData['percentage'];
        $termAverages[$term]['count']++;
    }
}

$overallPercentage = $totalMaxMarks > 0 ? ($totalMarks / $totalMaxMarks) * 100 : 0;

// Calculate term-wise averages
$term1Average = $termAverages['term1']['count'] > 0 ? 
    $termAverages['term1']['total'] / $termAverages['term1']['count'] : 0;
$term2Average = $termAverages['term2']['count'] > 0 ? 
    $termAverages['term2']['total'] / $termAverages['term2']['count'] : 0;

// Prepare data for charts
$chartLabels = [];
$chartTerm1Data = [];
$chartTerm2Data = [];

foreach ($studentResults as $subjectId => $subjectData) {
    $chartLabels[] = $subjectData['subject_name'];
    
    $term1Percentage = isset($subjectData['terms']['term1']) ? 
        $subjectData['terms']['term1']['percentage'] : null;
    $chartTerm1Data[] = $term1Percentage;
    
    $term2Percentage = isset($subjectData['terms']['term2']) ? 
        $subjectData['terms']['term2']['percentage'] : null;
    $chartTerm2Data[] = $term2Percentage;
}

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .welcome-banner {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .student-info {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-top: 1rem;
        }
        .info-item {
            background: rgba(255,255,255,0.1);
            padding: 0.5rem 1rem;
            border-radius: 8px;
            margin-right: 1rem;
            margin-bottom: 0.5rem;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .charts-container {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .marks-table th, .marks-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .marks-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            text-align: center;
        }
        .stat-value {
            font-size: 2rem;
            font-weight: 600;
            color: #2563eb;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            color: #6b7280;
            font-size: 0.875rem;
        }
        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="sdashboard.php">Dashboard</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>View your academic performance and results.</p>
            
            <div class="student-info">
                <div class="info-item">
                    <strong>Roll Number:</strong> <?php echo htmlspecialchars($studentData['roll_number']); ?>
                </div>
                <div class="info-item">
                    <strong>Class:</strong> <?php echo htmlspecialchars($studentData['class_name'] . ' ' . $studentData['division']); ?>
                </div>
                <div class="info-item">
                    <strong>School:</strong> <?php echo htmlspecialchars($studentData['school_name']); ?>
                </div>
            </div>
        </div>

        <div class="summary-stats">
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($overallPercentage, 1); ?>%</div>
                <div class="stat-label">Overall Average</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($term1Average, 1); ?>%</div>
                <div class="stat-label">Term 1 Average</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($term2Average, 1); ?>%</div>
                <div class="stat-label">Term 2 Average</div>
            </div>
        </div>

        <div class="charts-container">
            <div class="chart-card">
                <h2>Subject Performance</h2>
                <canvas id="marksChart"></canvas>
            </div>
        </div>

        <div class="card">
            <h2>Your Marks</h2>
            <?php if (!empty($studentResults)): ?>
                <table class="marks-table">
                    <thead>
                        <tr>
                            <th>Subject</th>
                            <th>Term 1</th>
                            <th>Term 2</th>
                            <th>Average</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($studentResults as $subjectId => $subjectData): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($subjectData['subject_name']); ?></td>
                                <td>
                                    <?php 
                                    if (isset($subjectData['terms']['term1'])) {
                                        echo $subjectData['terms']['term1']['marks_obtained'] . '/' . 
                                             $subjectData['terms']['term1']['total_marks'] . 
                                             ' (' . number_format($subjectData['terms']['term1']['percentage'], 1) . '%)';
                                    } else {
                                        echo 'Not recorded';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    if (isset($subjectData['terms']['term2'])) {
                                        echo $subjectData['terms']['term2']['marks_obtained'] . '/' . 
                                             $subjectData['terms']['term2']['total_marks'] . 
                                             ' (' . number_format($subjectData['terms']['term2']['percentage'], 1) . '%)';
                                    } else {
                                        echo 'Not recorded';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    $avgPercentage = 0;
                                    $termCount = 0;
                                    
                                    if (isset($subjectData['terms']['term1'])) {
                                        $avgPercentage += $subjectData['terms']['term1']['percentage'];
                                        $termCount++;
                                    }
                                    
                                    if (isset($subjectData['terms']['term2'])) {
                                        $avgPercentage += $subjectData['terms']['term2']['percentage'];
                                        $termCount++;
                                    }
                                    
                                    if ($termCount > 0) {
                                        $avgPercentage = $avgPercentage / $termCount;
                                        echo number_format($avgPercentage, 1) . '%';
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if ($termCount > 0) {
                                        if ($avgPercentage >= 90) echo 'A+';
                                        elseif ($avgPercentage >= 80) echo 'A';
                                        elseif ($avgPercentage >= 70) echo 'B';
                                        elseif ($avgPercentage >= 60) echo 'C';
                                        elseif ($avgPercentage >= 50) echo 'D';
                                        else echo 'F';
                                    } else {
                                        echo 'N/A';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No results have been recorded yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Chart for Subject Performance
        const marksCtx = document.getElementById('marksChart').getContext('2d');
        const marksChart = new Chart(marksCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($chartLabels); ?>,
                datasets: [
                    {
                        label: 'Term 1',
                        data: <?php echo json_encode($chartTerm1Data); ?>,
                        backgroundColor: 'rgba(54, 162, 235, 0.6)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Term 2',
                        data: <?php echo json_encode($chartTerm2Data); ?>,
                        backgroundColor: 'rgba(255, 99, 132, 0.6)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Percentage (%)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Subjects'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>