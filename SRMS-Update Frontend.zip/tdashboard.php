<?php
session_start();

// Check if user is logged in as teacher
if (!isset($_SESSION['username']) || $_SESSION['user_type'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

// Sample student data (in a real app, this would come from a database)
$students = [
    [
        'id' => 1,
        'name' => 'John Smith',
        'marks' => [
            'Math' => 85,
            'Science' => 92,
            'English' => 78,
            'History' => 88,
            'Computer Science' => 95
        ]
    ],
    [
        'id' => 2,
        'name' => 'Emma Johnson',
        'marks' => [
            'Math' => 92,
            'Science' => 88,
            'English' => 95,
            'History' => 76,
            'Computer Science' => 90
        ]
    ],
    [
        'id' => 3,
        'name' => 'Michael Brown',
        'marks' => [
            'Math' => 78,
            'Science' => 82,
            'English' => 85,
            'History' => 90,
            'Computer Science' => 75
        ]
    ]
];

// Calculate average marks per subject for chart
$subjectAverages = [];
$subjects = ['Math', 'Science', 'English', 'History', 'Computer Science'];

foreach ($subjects as $subject) {
    $total = 0;
    foreach ($students as $student) {
        $total += $student['marks'][$subject];
    }
    $subjectAverages[$subject] = round($total / count($students), 1);
}

// Calculate grade distribution for pie chart
$gradeDistribution = [
    'A+' => 0,
    'A' => 0,
    'B' => 0,
    'C' => 0,
    'D' => 0,
    'F' => 0
];

foreach ($students as $student) {
    foreach ($student['marks'] as $mark) {
        if ($mark >= 90) $gradeDistribution['A+']++;
        elseif ($mark >= 80) $gradeDistribution['A']++;
        elseif ($mark >= 70) $gradeDistribution['B']++;
        elseif ($mark >= 60) $gradeDistribution['C']++;
        elseif ($mark >= 50) $gradeDistribution['D']++;
        else $gradeDistribution['F']++;
    }
}

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .welcome-banner {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .charts-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .student-card {
            margin-bottom: 2rem;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 1rem;
        }
        .student-card:last-child {
            border-bottom: none;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .marks-table th, .marks-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .marks-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
            margin-right: 0.5rem;
        }
        .btn:hover {
            background: #1e40af;
        }
        .btn-secondary {
            background: #6b7280;
        }
        .btn-secondary:hover {
            background: #4b5563;
        }
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="tdashboard.php">Dashboard</a></li>
            <li><a href="update_marks.php">Update Marks</a></li>
            <li><a href="add_student.php">Add Student</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>Manage student marks and academic performance.</p>
        </div>

        <div class="action-buttons">
            <a href="update_marks.php" class="btn">Update Student Marks</a>
            <a href="add_student.php" class="btn">Add New Student</a>
            <a href="upload_marks.php" class="btn btn-secondary">Bulk Upload Marks</a>
        </div>

        <div class="charts-container">
            <div class="chart-card">
                <h2>Subject Averages</h2>
                <canvas id="barChart"></canvas>
            </div>
            <div class="chart-card">
                <h2>Grade Distribution</h2>
                <canvas id="pieChart"></canvas>
            </div>
        </div>

        <div class="card">
            <h2>Student Marks</h2>
            
            <?php foreach ($students as $student): ?>
                <div class="student-card">
                    <h3><?php echo htmlspecialchars($student['name']); ?></h3>
                    <table class="marks-table">
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Marks</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student['marks'] as $subject => $mark): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($subject); ?></td>
                                    <td><?php echo $mark; ?></td>
                                    <td>
                                        <?php
                                        if ($mark >= 90) echo 'A+';
                                        elseif ($mark >= 80) echo 'A';
                                        elseif ($mark >= 70) echo 'B';
                                        elseif ($mark >= 60) echo 'C';
                                        elseif ($mark >= 50) echo 'D';
                                        else echo 'F';
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        // Bar Chart for Subject Averages
        const barCtx = document.getElementById('barChart').getContext('2d');
        const barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($subjectAverages)); ?>,
                datasets: [{
                    label: 'Average Marks',
                    data: <?php echo json_encode(array_values($subjectAverages)); ?>,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        // Pie Chart for Grade Distribution
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        const pieChart = new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_keys($gradeDistribution)); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_values($gradeDistribution)); ?>,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(153, 102, 255, 0.6)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            }
        });
    </script>
</body>
</html>