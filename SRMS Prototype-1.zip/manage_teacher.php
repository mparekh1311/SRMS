<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$action = $_POST['action'] ?? '';
$response = ['success' => false, 'message' => ''];

try {
    if ($action === 'add') {
        $fullname = trim($_POST['fullname']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $send_to_email = trim($_POST['send_to_email']) ?: $email;
        $classes = $_POST['classes'] ?? [];
        $subjects = $_POST['subjects'] ?? [];
        
        if (empty($fullname) || empty($email)) {
            throw new Exception('Full name and email are required');
        }
        
        // Check if email already exists
        $checkStmt = $conn->prepare("SELECT user_id FROM User WHERE username = ?");
        $checkStmt->bind_param("s", $email);
        $checkStmt->execute();
        if ($checkStmt->get_result()->num_rows > 0) {
            throw new Exception('Email already exists');
        }
        
        // Generate password if not provided
        if (empty($password)) {
            $password = generateRandomPassword();
        }
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert user first
        $stmt = $conn->prepare("INSERT INTO User (username, password, fullname, role) VALUES (?, ?, ?, 'teacher')");
        $stmt->bind_param("sss", $email, $hashedPassword, $fullname);
        
        if ($stmt->execute()) {
            $userId = $conn->insert_id;
            
            // Insert teacher record
            $teacherStmt = $conn->prepare("INSERT INTO Teacher (user_id, school_id) VALUES (?, ?)");
            $teacherStmt->bind_param("ii", $userId, $_SESSION['school_id']);
            
            if ($teacherStmt->execute()) {
                $teacherId = $conn->insert_id;
                
                // Assign classes and subjects
                assignClassesAndSubjects($conn, $teacherId, $classes, $subjects);
                
                // Send credentials email (optional - implement if needed)
                // sendCredentialsEmail($send_to_email, $email, $password, $fullname);
                
                $response = ['success' => true, 'message' => 'Teacher added successfully'];
            } else {
                throw new Exception('Failed to add teacher record');
            }
        } else {
            throw new Exception('Failed to add user');
        }
        
    } elseif ($action === 'edit') {
        $teacherId = intval($_POST['teacher_id']);
        $fullname = trim($_POST['fullname']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $classes = $_POST['classes'] ?? [];
        $subjects = $_POST['subjects'] ?? [];
        
        if (empty($fullname) || empty($email) || empty($teacherId)) {
            throw new Exception('Full name, email, and teacher ID are required');
        }
        
        // Get user_id for this teacher
        $userStmt = $conn->prepare("SELECT user_id FROM Teacher WHERE teacher_id = ? AND school_id = ?");
        $userStmt->bind_param("ii", $teacherId, $_SESSION['school_id']);
        $userStmt->execute();
        $userResult = $userStmt->get_result();
        
        if ($userResult->num_rows === 0) {
            throw new Exception('Teacher not found');
        }
        
        $userId = $userResult->fetch_assoc()['user_id'];
        
        // Check if email exists for other users
        $checkStmt = $conn->prepare("SELECT user_id FROM User WHERE username = ? AND user_id != ?");
        $checkStmt->bind_param("si", $email, $userId);
        $checkStmt->execute();
        if ($checkStmt->get_result()->num_rows > 0) {
            throw new Exception('Email already exists for another user');
        }
        
        // Update user info
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE User SET username = ?, password = ?, fullname = ? WHERE user_id = ?");
            $stmt->bind_param("sssi", $email, $hashedPassword, $fullname, $userId);
        } else {
            $stmt = $conn->prepare("UPDATE User SET username = ?, fullname = ? WHERE user_id = ?");
            $stmt->bind_param("ssi", $email, $fullname, $userId);
        }
        
        if ($stmt->execute()) {
            // Update classes and subjects
            assignClassesAndSubjects($conn, $teacherId, $classes, $subjects);
            
            $response = ['success' => true, 'message' => 'Teacher updated successfully'];
        } else {
            throw new Exception('Failed to update teacher');
        }
        
    } elseif ($action === 'delete') {
        $teacherId = intval($_POST['teacher_id']);
        
        if (empty($teacherId)) {
            throw new Exception('Teacher ID is required');
        }
        
        // Delete teacher assignments first
        $deleteAssignStmt = $conn->prepare("DELETE FROM Teacher_Class_Subject WHERE teacher_id = ?");
        $deleteAssignStmt->bind_param("i", $teacherId);
        $deleteAssignStmt->execute();
        
        // Delete teacher record
        $stmt = $conn->prepare("DELETE FROM Teacher WHERE teacher_id = ? AND school_id = ?");
        $stmt->bind_param("ii", $teacherId, $_SESSION['school_id']);
        
        if ($stmt->execute() && $stmt->affected_rows > 0) {
            $response = ['success' => true, 'message' => 'Teacher deleted successfully'];
        } else {
            throw new Exception('Failed to delete teacher or teacher not found');
        }
        
    } else {
        throw new Exception('Invalid action');
    }
    
} catch (Exception $e) {
    $response = ['success' => false, 'message' => $e->getMessage()];
}

echo json_encode($response);

function generateRandomPassword($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return substr(str_shuffle($chars), 0, $length);
}

function assignClassesAndSubjects($conn, $teacherId, $classes, $subjects) {
    // Remove existing assignments
    $stmt = $conn->prepare("DELETE FROM Teacher_Class_Subject WHERE teacher_id = ?");
    $stmt->bind_param("i", $teacherId);
    $stmt->execute();
    
    // Assign classes and subjects (combined table)
    if (!empty($classes) && !empty($subjects)) {
        $stmt = $conn->prepare("INSERT INTO Teacher_Class_Subject (teacher_id, class_id, subject_id) VALUES (?, ?, ?)");
        foreach ($classes as $classId) {
            foreach ($subjects as $subjectId) {
                $stmt->bind_param("iii", $teacherId, $classId, $subjectId);
                $stmt->execute();
            }
        }
    }
}
?>