<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

try {
    $classId = intval($_POST['class_id']);
    $subjectId = intval($_POST['subject_id']);
    $totalMarks = intval($_POST['total_marks']);
    $marks = $_POST['marks'] ?? [];
    
    if (empty($classId) || empty($subjectId) || empty($totalMarks)) {
        throw new Exception('Class, subject, and total marks are required');
    }
    
    $saved = 0;
    foreach ($marks as $studentId => $marksObtained) {
        if (!empty($marksObtained) && is_numeric($marksObtained)) {
            // Check if result already exists
            $checkStmt = $conn->prepare("SELECT result_id FROM result WHERE student_id = ? AND subject_id = ?");
            $checkStmt->bind_param("ii", $studentId, $subjectId);
            $checkStmt->execute();
            
            if ($checkStmt->get_result()->num_rows > 0) {
                // Update existing result
                $updateStmt = $conn->prepare("UPDATE result SET marks_obtained = ?, total_subject_marks = ? WHERE student_id = ? AND subject_id = ?");
                $updateStmt->bind_param("iiii", $marksObtained, $totalMarks, $studentId, $subjectId);
                $updateStmt->execute();
            } else {
                // Insert new result
                $insertStmt = $conn->prepare("INSERT INTO result (student_id, subject_id, marks_obtained, total_subject_marks) VALUES (?, ?, ?, ?)");
                $insertStmt->bind_param("iiii", $studentId, $subjectId, $marksObtained, $totalMarks);
                $insertStmt->execute();
            }
            $saved++;
        }
    }
    
    echo json_encode(['success' => true, 'message' => "Marks saved for $saved students"]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>