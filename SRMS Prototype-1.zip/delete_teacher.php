<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacherId = $_POST['teacher_id'];
    $schoolId = $_SESSION['school_id'];
    
    try {
        $conn->begin_transaction();
        
        // Get user_id from teacher
        $getUserQuery = "SELECT user_id FROM Teacher WHERE teacher_id = ? AND school_id = ?";
        $stmt = $conn->prepare($getUserQuery);
        $stmt->bind_param("ii", $teacherId, $schoolId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Teacher not found");
        }
        
        $userId = $result->fetch_assoc()['user_id'];
        
        // Delete from Teacher_Class_Subject
        $deleteAssignQuery = "DELETE FROM Teacher_Class_Subject WHERE teacher_id = ?";
        $stmt = $conn->prepare($deleteAssignQuery);
        $stmt->bind_param("i", $teacherId);
        $stmt->execute();
        
        // Delete from Teacher
        $deleteTeacherQuery = "DELETE FROM Teacher WHERE teacher_id = ?";
        $stmt = $conn->prepare($deleteTeacherQuery);
        $stmt->bind_param("i", $teacherId);
        $stmt->execute();
        
        // Delete from User
        $deleteUserQuery = "DELETE FROM User WHERE user_id = ?";
        $stmt = $conn->prepare($deleteUserQuery);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        
        $conn->commit();
        
        $response['success'] = true;
        $response['message'] = 'Teacher deleted successfully!';
        
    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = 'Error deleting teacher: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>