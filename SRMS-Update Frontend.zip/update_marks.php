<?php
session_start();

// Check if user is logged in as teacher
if (!isset($_SESSION['username']) || $_SESSION['user_type'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

// Sample student data (in a real app, this would come from a database)
$students = [
    [
        'id' => 1,
        'name' => 'John Smith',
        'marks' => [
            'Math' => 85,
            'Science' => 92,
            'English' => 78,
            'History' => 88,
            'Computer Science' => 95
        ]
    ],
    [
        'id' => 2,
        'name' => 'Emma Johnson',
        'marks' => [
            'Math' => 92,
            'Science' => 88,
            'English' => 95,
            'History' => 76,
            'Computer Science' => 90
        ]
    ],
    [
        'id' => 3,
        'name' => 'Michael Brown',
        'marks' => [
            'Math' => 78,
            'Science' => 82,
            'English' => 85,
            'History' => 90,
            'Computer Science' => 75
        ]
    ]
];

$message = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_marks'])) {
    $studentId = $_POST['student_id'];
    $subject = $_POST['subject'];
    $newMark = $_POST['mark'];
    
    // Validate input
    if ($newMark >= 0 && $newMark <= 100) {
        // In a real app, you would update the database here
        $message = "Marks updated successfully for " . $_POST['student_name'] . " in " . $subject;
    } else {
        $message = "Error: Mark must be between 0 and 100";
    }
}

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Marks - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .page-header {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .marks-table th, .marks-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .marks-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #1e40af;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-family: inherit;
            font-size: 1rem;
        }
        .message {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            background-color: #e6f7ff;
            border-left: 4px solid #2563eb;
        }
        .error {
            background-color: #fff5f5;
            border-left-color: #e53e3e;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="tdashboard.php">Dashboard</a></li>
            <li><a href="update_marks.php">Update Marks</a></li>
            <li><a href="add_student.php">Add Student</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Update Student Marks</h1>
            <p>Modify marks for individual students and subjects.</p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo strpos($message, 'Error') !== false ? 'error' : ''; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <h2>Update Marks</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="student_id">Select Student:</label>
                    <select name="student_id" id="student_id" class="form-control" required>
                        <option value="">-- Select Student --</option>
                        <?php foreach ($students as $student): ?>
                            <option value="<?php echo $student['id']; ?>" data-name="<?php echo htmlspecialchars($student['name']); ?>">
                                <?php echo htmlspecialchars($student['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="hidden" name="student_name" id="student_name" value="">
                </div>
                
                <div class="form-group">
                    <label for="subject">Select Subject:</label>
                    <select name="subject" id="subject" class="form-control" required>
                        <option value="">-- Select Subject --</option>
                        <option value="Math">Math</option>
                        <option value="Science">Science</option>
                        <option value="English">English</option>
                        <option value="History">History</option>
                        <option value="Computer Science">Computer Science</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="mark">New Mark (0-100):</label>
                    <input type="number" name="mark" id="mark" class="form-control" min="0" max="100" required>
                </div>
                
                <button type="submit" name="update_marks" class="btn">Update Mark</button>
            </form>
        </div>

        <div class="card">
            <h2>Current Marks</h2>
            <?php foreach ($students as $student): ?>
                <div class="student-section">
                    <h3><?php echo htmlspecialchars($student['name']); ?></h3>
                    <table class="marks-table">
                        <thead>
                            <tr>
                                <th>Subject</th>
                                <th>Marks</th>
                                <th>Grade</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student['marks'] as $subject => $mark): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($subject); ?></td>
                                    <td><?php echo $mark; ?></td>
                                    <td>
                                        <?php
                                        if ($mark >= 90) echo 'A+';
                                        elseif ($mark >= 80) echo 'A';
                                        elseif ($mark >= 70) echo 'B';
                                        elseif ($mark >= 60) echo 'C';
                                        elseif ($mark >= 50) echo 'D';
                                        else echo 'F';
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        // Set student name when student is selected
        document.getElementById('student_id').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            document.getElementById('student_name').value = selectedOption.dataset.name;
        });
    </script>
</body>
</html>