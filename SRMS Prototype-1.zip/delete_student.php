<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = $_POST['student_id'];
    $schoolId = $_SESSION['school_id'];
    
    try {
        $conn->begin_transaction();
        
        // Get user_id from student
        $getUserQuery = "SELECT user_id FROM Student WHERE student_id = ? AND school_id = ?";
        $stmt = $conn->prepare($getUserQuery);
        $stmt->bind_param("ii", $studentId, $schoolId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Student not found");
        }
        
        $userId = $result->fetch_assoc()['user_id'];
        
        // Delete from result
        $deleteResultQuery = "DELETE FROM result WHERE student_id = ?";
        $stmt = $conn->prepare($deleteResultQuery);
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        
        // Delete from Student
        $deleteStudentQuery = "DELETE FROM Student WHERE student_id = ?";
        $stmt = $conn->prepare($deleteStudentQuery);
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
        
        // Delete from User
        $deleteUserQuery = "DELETE FROM User WHERE user_id = ?";
        $stmt = $conn->prepare($deleteUserQuery);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        
        $conn->commit();
        
        $response['success'] = true;
        $response['message'] = 'Student deleted successfully!';
        
    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = 'Error deleting student: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>