<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    die('Unauthorized');
}

echo "<h3>Available Tables:</h3>";
$result = $conn->query("SHOW TABLES");
while ($row = $result->fetch_array()) {
    echo $row[0] . "<br>";
}

echo "<h3>Class Table Structure:</h3>";
$result = $conn->query("DESCRIBE Class");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "<br>";
    }
} else {
    echo "Class table not found<br>";
}

echo "<h3>Subject Table Structure:</h3>";
$result = $conn->query("DESCRIBE Subject");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " - " . $row['Type'] . "<br>";
    }
} else {
    echo "Subject table not found<br>";
}

echo "<h3>Sample Classes:</h3>";
$result = $conn->query("SELECT * FROM Class WHERE school_id = " . $_SESSION['school_id'] . " LIMIT 5");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        print_r($row);
        echo "<br>";
    }
} else {
    echo "No classes found<br>";
}

echo "<h3>Sample Subjects:</h3>";
$result = $conn->query("SELECT * FROM Subject WHERE school_id = " . $_SESSION['school_id'] . " LIMIT 5");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        print_r($row);
        echo "<br>";
    }
} else {
    echo "No subjects found<br>";
}
?>