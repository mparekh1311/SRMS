<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

try {
    $studentId = intval($_POST['student_id']);
    $subjectId = intval($_POST['subject_id']);
    $term = $_POST['term'];
    $marksObtained = intval($_POST['marks_obtained']);
    $totalMarks = intval($_POST['total_marks']);
    
    if (empty($studentId) || empty($subjectId) || empty($term)) {
        throw new Exception('Student, subject, and term are required');
    }
    
    // Get student's class_id
    $classStmt = $conn->prepare("SELECT class_id FROM Student WHERE student_id = ?");
    $classStmt->bind_param("i", $studentId);
    $classStmt->execute();
    $classResult = $classStmt->get_result();
    
    if ($classResult->num_rows === 0) {
        throw new Exception('Student not found');
    }
    
    $classId = $classResult->fetch_assoc()['class_id'];
    
    // Check if result already exists
    $checkStmt = $conn->prepare("SELECT result_id FROM Result WHERE student_id = ? AND subject_id = ? AND exam_term = ?");
    $checkStmt->bind_param("iis", $studentId, $subjectId, $term);
    $checkStmt->execute();
    
    if ($checkStmt->get_result()->num_rows > 0) {
        // Update existing result
        $updateStmt = $conn->prepare("UPDATE Result SET marks_obtained = ?, total_subject_marks = ?, class_id = ? WHERE student_id = ? AND subject_id = ? AND exam_term = ?");
        $updateStmt->bind_param("iiiis", $marksObtained, $totalMarks, $classId, $studentId, $subjectId, $term);
        $updateStmt->execute();
        $message = 'Mark updated successfully';
    } else {
        // Insert new result with class_id
        $insertStmt = $conn->prepare("INSERT INTO Result (student_id, class_id, subject_id, exam_term, marks_obtained, total_subject_marks, recorded_by_teacher_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $insertStmt->bind_param("iiisiii", $studentId, $classId, $subjectId, $term, $marksObtained, $totalMarks, $_SESSION['user_id']);
        $insertStmt->execute();
        $message = 'Mark added successfully';
    }
    
    echo json_encode(['success' => true, 'message' => $message]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>