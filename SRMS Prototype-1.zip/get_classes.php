<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

$schoolId = intval($_GET['school_id'] ?? 0);

if (empty($schoolId)) {
    echo json_encode(['success' => false, 'classes' => []]);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT class_id, class_name, division FROM Class WHERE school_id = ? ORDER BY class_name, division");
    $stmt->bind_param("i", $schoolId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $classes = [];
    while ($row = $result->fetch_assoc()) {
        $classes[] = $row;
    }
    
    echo json_encode(['success' => true, 'classes' => $classes]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'classes' => []]);
}
?>