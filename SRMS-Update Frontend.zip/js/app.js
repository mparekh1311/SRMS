'use strict';

const e = React.createElement;
const { useState, useEffect } = React;

const NAV_ITEMS = {
  loggedOut: ['Login'],
  student: ['Dashboard', 'View Results', 'Logout'],
  teacher: ['Dashboard', 'Enter Grades', 'Logout'],
};

// Mock Data
let mockStudents = [
  { id: 1, name: 'Jay Patel', username: 'student1', password: 'pass123', grades: [{ course: 'Math', grade: 88 }, { course: 'Science', grade: 92 }] },
  { id: 2, name: 'Asha Desai', username: 'student2', password: 'pass123', grades: [{ course: 'Math', grade: 75 }, { course: 'Science', grade: 80 }] },
];

const mockTeachers = [
  { id: 1, name: 'Mr. Mehta', username: 'teacher1', password: 'pass123' }
];

function Navbar({ user, onNavClick }) {
  const items = user ? NAV_ITEMS[user.role] : NAV_ITEMS.loggedOut;

  useEffect(() => {
    anime({
      targets: '#nav-links li',
      translateY: [-20, 0],
      opacity: [0, 1],
      delay: anime.stagger(100),
      easing: 'easeOutQuad',
    });
  }, [user]);

  return e('nav', { className: 'navbar' },
    e('div', { className: 'logo' }, '🎓 Canvas RMS'),
    e('ul', { id: 'nav-links', className: 'nav-links' },
      items.map(item => 
        e('li', { key: item },
          e('a', {
            href: '#',
            onClick: (ev) => { ev.preventDefault(); onNavClick(item); }
          }, item)
        )
      )
    )
  );
}

function Login({ onLogin }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    let user = mockStudents.find(u => u.username === username && u.password === password);
    if (user) {
      onLogin({ ...user, role: 'student' });
      return;
    }
    user = mockTeachers.find(u => u.username === username && u.password === password);
    if (user) {
      onLogin({ ...user, role: 'teacher' });
      return;
    }
    setError('Invalid username or password');
  }

  useEffect(() => {
    anime.timeline()
      .add({
        targets: '.form-group',
        translateX: [-100, 0],
        opacity: [0, 1],
        delay: anime.stagger(150),
        easing: 'easeOutQuad',
      });
  }, []);

  return e('div', { className: 'form-container' },
    e('h2', null, 'Login'),
    error && e('p', { className: 'error-message' }, error),
    e('form', { onSubmit: handleSubmit },
      e('div', { className: 'form-group' },
        e('label', { htmlFor: 'username' }, 'Username'),
        e('input', {
          id: 'username', type: 'text', value: username, required: true,
          onChange: e => setUsername(e.target.value)
        })
      ),
      e('div', { className: 'form-group' },
        e('label', { htmlFor: 'password' }, 'Password'),
        e('input', {
          id: 'password', type: 'password', value: password, required: true,
          onChange: e => setPassword(e.target.value)
        })
      ),
      e('button', { type: 'submit', className: 'btn' }, 'Login')
    )
  );
}

function StudentDashboard({ user }) {
  return e('div', { className: 'dashboard-container' },
    e('h2', null, 'Student Dashboard'),
    e('p', { className: 'dashboard-welcome' }, `Welcome back, ${user.name}!`),
    e('h3', null, 'Your Grades:'),
    e('table', { className: 'table' },
      e('thead', null,
        e('tr', null,
          e('th', null, 'Course'),
          e('th', null, 'Grade')
        )
      ),
      e('tbody', null,
        user.grades.map((g, i) =>
          e('tr', { key: i },
            e('td', null, g.course),
            e('td', null, g.grade)
          )
        )
      )
    )
  );
}

function TeacherDashboard({ user, onNavigate }) {
  return e('div', { className: 'dashboard-container' },
    e('h2', null, 'Teacher Dashboard'),
    e('p', { className: 'dashboard-welcome' }, `Welcome back, ${user.name}!`),
    e('button', { className: 'btn', onClick: () => onNavigate('Enter Grades') }, 'Enter Grades')
  );
}

function EnterGrades({ onSubmit, onCancel }) {
  const [studentUsername, setStudentUsername] = useState('');
  const [course, setCourse] = useState('');
  const [grade, setGrade] = useState('');
  const [message, setMessage] = useState('');

  function handleSubmit(e) {
    e.preventDefault();
    if (!studentUsername || !course || !grade) {
      setMessage('Please fill all fields.');
      return;
    }

    const studentIndex = mockStudents.findIndex(s => s.username === studentUsername);
    if (studentIndex === -1) {
      setMessage('Student username not found.');
      return;
    }

    const grades = mockStudents[studentIndex].grades;
    const courseIndex = grades.findIndex(g => g.course.toLowerCase() === course.toLowerCase());

    if (courseIndex >= 0) {
      grades[courseIndex].grade = Number(grade);
    } else {
      grades.push({ course, grade: Number(grade) });
    }

    setMessage(`Grade updated for ${mockStudents[studentIndex].name} in ${course}: ${grade}`);

    onSubmit({ studentUsername, course, grade: Number(grade) });

    setStudentUsername('');
    setCourse('');
    setGrade('');
  }

  useEffect(() => {
    anime({
      targets: '.form-container',
      opacity: [0, 1],
      translateY: [20, 0],
      easing: 'easeOutQuad',
      duration: 600,
    });
  }, []);

  return e('div', { className: 'form-container' },
    e('h2', null, 'Enter Grades'),
    message && e('p', { className: 'success-message' }, message),
    e('form', { onSubmit: handleSubmit },
      e('div', { className: 'form-group' },
        e('label', null, 'Student Username'),
        e('input', {
          type: 'text', value: studentUsername,
          onChange: e => setStudentUsername(e.target.value), required: true,
          placeholder: "e.g. student1"
        })
      ),
      e('div', { className: 'form-group' },
        e('label', null, 'Course'),
        e('input', {
          type: 'text', value: course,
          onChange: e => setCourse(e.target.value), required: true,
          placeholder: "e.g. Math"
        })
      ),
      e('div', { className: 'form-group' },
        e('label', null, 'Grade'),
        e('input', {
          type: 'number', value: grade, min: 0, max: 100,
          onChange: e => setGrade(e.target.value), required: true,
          placeholder: "0 - 100"
        })
      ),
      e('div', { style: { display: 'flex', justifyContent: 'space-between' } },
        e('button', { type: 'submit', className: 'btn' }, 'Submit'),
        e('button', { type: 'button', className: 'btn cancel-btn', onClick: onCancel }, 'Cancel')
      )
    )
  );
}

function ViewResults({ user }) {
  return e('div', { className: 'dashboard-container' },
    e('h2', null, 'View Results'),
    e('p', { className: 'dashboard-welcome' }, `Results for ${user.name}:`),
    e('table', { className: 'table' },
      e('thead', null,
        e('tr', null,
          e('th', null, 'Course'),
          e('th', null, 'Grade')
        )
      ),
      e('tbody', null,
        user.grades.map((g, i) =>
          e('tr', { key: i },
            e('td', null, g.course),
            e('td', null, g.grade)
          )
        )
      )
    )
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [page, setPage] = useState('Login');

  useEffect(() => {
    if (user && user.role === 'student') {
      const updatedUser = mockStudents.find(s => s.username === user.username);
      if (updatedUser) setUser({ ...updatedUser, role: 'student' });
    }
  }, [page]);

  useEffect(() => {
    if (!user) setPage('Login');
  }, [user]);

  function handleNavClick(item) {
    if (item === 'Logout') {
      setUser(null);
      setPage('Login');
    } else {
      setPage(item);
    }
  }

  function handleLogin(u) {
    setUser(u);
    setPage('Dashboard');
  }

  function handleGradeSubmit({ studentUsername, course, grade }) {
    // grade update already done in EnterGrades
    console.log(`Grades submitted for ${studentUsername} in ${course}: ${grade}`);
  }

  return e(React.Fragment, null,
    e(Navbar, { user: user, onNavClick: handleNavClick }),
    e('main', { key: page, className: 'app-main' },
      page === 'Login' && e(Login, { onLogin: handleLogin }),
      page === 'Dashboard' && user && (user.role === 'student'
        ? e(StudentDashboard, { user })
        : e(TeacherDashboard, { user, onNavigate: setPage })),
      page === 'View Results' && user && user.role === 'student' && e(ViewResults, { user }),
      page === 'Enter Grades' && user && user.role === 'teacher' && e(EnterGrades, { onSubmit: handleGradeSubmit, onCancel: () => setPage('Dashboard') })
    )
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(e(App));
