<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

// Get teacher information
$teacherId = 0;
$query = "SELECT t.teacher_id FROM Teacher t WHERE t.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $teacherId = $row['teacher_id'];
}

// Get classes and subjects taught by this teacher
$classesQuery = "
    SELECT c.class_id, c.class_name, c.division, s.subject_id, s.subject_name
    FROM Teacher_Class_Subject tcs
    JOIN Class c ON tcs.class_id = c.class_id
    JOIN Subject s ON tcs.subject_id = s.subject_id
    WHERE tcs.teacher_id = ?
    ORDER BY c.class_name, c.division
";
$stmt = $conn->prepare($classesQuery);
$stmt->bind_param("i", $teacherId);
$stmt->execute();
$classesResult = $stmt->get_result();

$teacherClasses = [];
while ($row = $classesResult->fetch_assoc()) {
    $classId = $row['class_id'];
    if (!isset($teacherClasses[$classId])) {
        $teacherClasses[$classId] = [
            'class_name' => $row['class_name'],
            'division' => $row['division'],
            'subjects' => []
        ];
    }
    $teacherClasses[$classId]['subjects'][] = [
        'subject_id' => $row['subject_id'],
        'subject_name' => $row['subject_name']
    ];
}

$message = '';
$messageType = '';

// Handle AJAX upload request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_upload'])) {
    header('Content-Type: application/json');

    try {
        $classId = intval($_POST['class_id'] ?? 0);
        $subjectId = intval($_POST['subject_id'] ?? 0);
        $totalMarks = intval($_POST['total_marks'] ?? 100);
        $examTerm = $_POST['exam_term'] ?? 'term1';
        
        if (empty($classId) || empty($subjectId)) {
            throw new Exception('Class and subject are required');
        }
        
        if (!isset($_FILES['excel_file']) || $_FILES['excel_file']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Please upload a valid file');
        }
        
        $uploadedFile = $_FILES['excel_file']['tmp_name'];
        $fileName = $_FILES['excel_file']['name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        $data = [];
        
        if ($fileExt === 'csv') {
            $handle = fopen($uploadedFile, 'r');
            if (!$handle) {
                throw new Exception('Could not read the uploaded file');
            }
            
            $header = fgetcsv($handle);
            while (($row = fgetcsv($handle)) !== FALSE) {
                $data[] = $row;
            }
            fclose($handle);
        } elseif ($fileExt === 'xlsx') {
            // Convert Excel to CSV using a simple method
            $tempCsv = tempnam(sys_get_temp_dir(), 'excel_');
            
            // Try to use a simple conversion method
            if (class_exists('ZipArchive')) {
                $zip = new ZipArchive();
                if ($zip->open($uploadedFile) === TRUE) {
                    $worksheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
                    if ($worksheetXml) {
                        // Simple XML parsing for basic Excel files
                        $xml = simplexml_load_string($worksheetXml);
                        $csvHandle = fopen($tempCsv, 'w');
                        
                        foreach ($xml->sheetData->row as $row) {
                            $rowData = [];
                            foreach ($row->c as $cell) {
                                $value = isset($cell->v) ? (string)$cell->v : '';
                                $rowData[] = $value;
                            }
                            fputcsv($csvHandle, $rowData);
                        }
                        fclose($csvHandle);
                        
                        // Now read the CSV
                        $handle = fopen($tempCsv, 'r');
                        $header = fgetcsv($handle);
                        while (($row = fgetcsv($handle)) !== FALSE) {
                            $data[] = $row;
                        }
                        fclose($handle);
                        unlink($tempCsv);
                    }
                    $zip->close();
                } else {
                    throw new Exception('Could not read Excel file. Please save as CSV instead.');
                }
            } else {
                throw new Exception('Excel support not available. Please upload CSV file.');
            }
        } else {
            throw new Exception('Unsupported file format. Please upload CSV or XLSX files.');
        }
        
        $saved = 0;
        $skipped = 0;
        
        foreach ($data as $row) {
            if (count($row) < 2) {
                $skipped++;
                continue;
            }
            
            $studentName = trim($row[0]);
            $marksObtained = floatval($row[1]);
            
            if (empty($studentName) || $marksObtained < 0) {
                $skipped++;
                continue;
            }
            
            // Find student by exact name match in the specified class
            $studentStmt = $conn->prepare("
                SELECT s.student_id 
                FROM Student s 
                JOIN User u ON s.user_id = u.user_id 
                WHERE u.fullname = ? AND s.class_id = ?
            ");
            $studentStmt->bind_param("si", $studentName, $classId);
            $studentStmt->execute();
            $studentResult = $studentStmt->get_result();
            
            if ($studentResult->num_rows > 0) {
                $studentId = $studentResult->fetch_assoc()['student_id'];
                
                // Check if result already exists
                $checkStmt = $conn->prepare("SELECT result_id FROM Result WHERE student_id = ? AND subject_id = ? AND exam_term = ?");
                $checkStmt->bind_param("iis", $studentId, $subjectId, $examTerm);
                $checkStmt->execute();
                
                if ($checkStmt->get_result()->num_rows > 0) {
                    // Update existing result
                    $updateStmt = $conn->prepare("UPDATE Result SET marks_obtained = ?, total_subject_marks = ?, recorded_by_teacher_id = ? WHERE student_id = ? AND subject_id = ? AND exam_term = ?");
                    $updateStmt->bind_param("ddiis", $marksObtained, $totalMarks, $teacherId, $studentId, $subjectId, $examTerm);
                    $updateStmt->execute();
                } else {
                    // Insert new result
                    $insertStmt = $conn->prepare("INSERT INTO Result (student_id, class_id, subject_id, exam_term, marks_obtained, total_subject_marks, recorded_by_teacher_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $insertStmt->bind_param("iiisddi", $studentId, $classId, $subjectId, $examTerm, $marksObtained, $totalMarks, $teacherId);
                    $insertStmt->execute();
                }
                $saved++;
            } else {
                $skipped++;
            }
        }
        
        echo json_encode(['success' => true, 'message' => "Marks uploaded for $saved students. $skipped records skipped."]);
        
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bulk Upload Marks - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f9fafc; color: #333; padding-top: 80px; }
        .navbar { position: fixed; width: 100%; top: 0; background: rgba(255,255,255,0.9); backdrop-filter: blur(8px); display: flex; justify-content: space-between; align-items: center; padding: 1rem 2rem; box-shadow: 0 2px 10px rgba(0,0,0,0.05); z-index: 1000; }
        .logo { font-weight: 700; font-size: 1.5rem; color: #2563eb; }
        .nav-links { display: flex; gap: 1.5rem; list-style: none; }
        .nav-links a { text-decoration: none; color: #333; font-weight: 500; transition: color 0.3s ease; }
        .nav-links a:hover { color: #2563eb; }
        .container { max-width: 1000px; margin: 2rem auto; padding: 0 1rem; }
        .page-header { background: #2563eb; color: white; padding: 2rem; border-radius: 12px; margin-bottom: 2rem; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .card { background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 1.5rem; }
        .form-group { margin-bottom: 1rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        .form-control { width: 100%; padding: 0.75rem; border: 1px solid #ccc; border-radius: 8px; font-family: inherit; font-size: 1rem; }
        .btn { display: inline-block; background: #2563eb; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 8px; cursor: pointer; text-decoration: none; font-weight: 500; transition: background 0.3s ease; }
        .btn:hover { background: #1e40af; }
        .message { padding: 1rem; margin-bottom: 1rem; border-radius: 8px; }
        .message.success { background-color: #e6f7ff; border-left: 4px solid #2563eb; }
        .message.error { background-color: #fff5f5; border-left: 4px solid #e53e3e; }
        .sample-format { background: #f8f9fa; padding: 1rem; border-radius: 8px; margin: 1rem 0; }
        .sample-format pre { font-family: monospace; font-size: 0.9rem; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="tdashboard.php">Dashboard</a></li>
            <li><a href="update_marks.php">Update Marks</a></li>
            <li><a href="upload_marks.php">Bulk Upload</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Bulk Upload Marks</h1>
            <p>Upload marks for multiple students using CSV file.</p>
        </div>

        <div id="message"></div>

        <div class="card">
            <h2>Upload CSV File</h2>
            
            <?php if (!empty($teacherClasses)): ?>
                <form id="uploadForm" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="class_id">Select Class:</label>
                        <select name="class_id" id="class_id" class="form-control" required>
                            <option value="">-- Select Class --</option>
                            <?php foreach ($teacherClasses as $classId => $classData): ?>
                                <option value="<?php echo $classId; ?>">
                                    <?php echo htmlspecialchars($classData['class_name'] . ' ' . $classData['division']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject_id">Select Subject:</label>
                        <select name="subject_id" id="subject_id" class="form-control" required disabled>
                            <option value="">-- Select Subject --</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="exam_term">Select Exam Term:</label>
                        <select name="exam_term" id="exam_term" class="form-control" required>
                            <option value="term1">Term 1</option>
                            <option value="term2">Term 2</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="total_marks">Total Marks:</label>
                        <input type="number" name="total_marks" id="total_marks" class="form-control" min="1" value="100" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="excel_file">CSV File (recommended) or Excel:</label>
                        <input type="file" name="excel_file" id="excel_file" class="form-control" accept=".csv,.xlsx" required>
                    </div>
                    
                    <button type="submit" class="btn">Upload Marks</button>
                </form>
                
                <div class="sample-format">
                    <h3>File Format (CSV recommended):</h3>
                    <pre>Student Name,Marks Obtained
Arjun Singh,85
Riya Sharma,92
Kiran Rao,78</pre>
                    <p><strong>Note:</strong> Student names must match exactly as stored in the database. CSV format is recommended for best compatibility.</p>
                </div>
                
                <script>
                    const classData = <?php echo json_encode($teacherClasses); ?>;
                    
                    document.getElementById('class_id').addEventListener('change', function() {
                        const classId = this.value;
                        const subjectSelect = document.getElementById('subject_id');
                        
                        subjectSelect.innerHTML = '<option value="">-- Select Subject --</option>';
                        subjectSelect.disabled = !classId;
                        
                        if (classId && classData[classId]) {
                            const subjects = classData[classId].subjects;
                            subjects.forEach(subject => {
                                const option = document.createElement('option');
                                option.value = subject.subject_id;
                                option.textContent = subject.subject_name;
                                subjectSelect.appendChild(option);
                            });
                        }
                    });
                    
                    document.getElementById('uploadForm').addEventListener('submit', function(e) {
                        e.preventDefault();
                        
                        const formData = new FormData(this);
                        formData.append('ajax_upload', '1');
                        
                        const messageDiv = document.getElementById('message');
                        messageDiv.innerHTML = '<div class="message">Uploading...</div>';
                        
                        fetch('upload_marks.php', {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            const messageClass = data.success ? 'success' : 'error';
                            messageDiv.innerHTML = `<div class="message ${messageClass}">${data.message}</div>`;
                            if (data.success) {
                                this.reset();
                                document.getElementById('subject_id').disabled = true;
                            }
                        })
                        .catch(error => {
                            messageDiv.innerHTML = '<div class="message error">Upload failed. Please try again.</div>';
                        });
                    });
                </script>
            <?php else: ?>
                <p>You are not assigned to any classes yet.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>