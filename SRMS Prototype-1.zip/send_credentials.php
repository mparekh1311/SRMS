<?php
session_start();
require_once 'db_connect.php';
require_once 'email_config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $teacherId = $_POST['teacher_id'];
    $newPassword = generatePassword();
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    try {
        // Get teacher details
        $teacherQuery = "SELECT u.fullname, u.username, u.user_id FROM Teacher t 
                        JOIN User u ON t.user_id = u.user_id 
                        WHERE t.teacher_id = ? AND t.school_id = ?";
        $stmt = $conn->prepare($teacherQuery);
        $stmt->bind_param("ii", $teacherId, $_SESSION['school_id']);
        $stmt->execute();
        $teacher = $stmt->get_result()->fetch_assoc();
        
        if ($teacher) {
            // Update password
            $updateQuery = "UPDATE User SET password = ? WHERE user_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("si", $hashedPassword, $teacher['user_id']);
            $stmt->execute();
            
            // Send email
            if (sendCredentialEmail($teacher['username'], $teacher['fullname'], $teacher['username'], $newPassword)) {
                $response['success'] = true;
                $response['message'] = 'New credentials sent successfully!';
            } else {
                $response['success'] = true;
                $response['message'] = 'Password updated but email failed. New password: ' . $newPassword;
            }
        } else {
            $response['message'] = 'Teacher not found!';
        }
        
    } catch (Exception $e) {
        $response['message'] = 'Error sending credentials: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>