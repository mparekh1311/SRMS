<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in as principal
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$schoolId = $_SESSION['school_id'];

// Get school information
$schoolQuery = "SELECT * FROM School WHERE school_id = ?";
$stmt = $conn->prepare($schoolQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$schoolData = $stmt->get_result()->fetch_assoc();

// Get statistics
$studentsQuery = "SELECT COUNT(*) as count FROM Student WHERE school_id = ?";
$stmt = $conn->prepare($studentsQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$studentCount = $stmt->get_result()->fetch_assoc()['count'];

$teachersQuery = "SELECT COUNT(*) as count FROM Teacher WHERE school_id = ?";
$stmt = $conn->prepare($teachersQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$teacherCount = $stmt->get_result()->fetch_assoc()['count'];

$classesQuery = "SELECT COUNT(*) as count FROM Class WHERE school_id = ?";
$stmt = $conn->prepare($classesQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$classCount = $stmt->get_result()->fetch_assoc()['count'];

// Get recent results for performance overview
$recentResultsQuery = "
    SELECT AVG(r.marks_obtained / r.total_subject_marks * 100) as avg_percentage
    FROM result r
    JOIN Student s ON r.student_id = s.student_id
    WHERE s.school_id = ?
";
$stmt = $conn->prepare($recentResultsQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$avgPerformance = $stmt->get_result()->fetch_assoc()['avg_percentage'] ?? 0;

// Get class-wise performance
$classPerformanceQuery = "
    SELECT c.class_name, c.division, 
           AVG(r.marks_obtained / r.total_subject_marks * 100) as avg_percentage,
           COUNT(DISTINCT s.student_id) as student_count
    FROM Class c
    LEFT JOIN Student s ON c.class_id = s.class_id
    LEFT JOIN result r ON s.student_id = r.student_id
    WHERE c.school_id = ?
    GROUP BY c.class_id, c.class_name, c.division
    ORDER BY c.class_name, c.division
";
$stmt = $conn->prepare($classPerformanceQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$classPerformance = $stmt->get_result();

// Get teachers list
$teachersListQuery = "
    SELECT t.teacher_id, u.fullname, u.username,
           GROUP_CONCAT(DISTINCT CONCAT(c.class_name, ' ', c.division) SEPARATOR ', ') as classes,
           GROUP_CONCAT(DISTINCT sub.subject_name SEPARATOR ', ') as subjects
    FROM Teacher t
    JOIN User u ON t.user_id = u.user_id
    LEFT JOIN Teacher_Class_Subject tcs ON t.teacher_id = tcs.teacher_id
    LEFT JOIN Class c ON tcs.class_id = c.class_id
    LEFT JOIN Subject sub ON tcs.subject_id = sub.subject_id
    WHERE t.school_id = ?
    GROUP BY t.teacher_id, u.fullname, u.username
";
$stmt = $conn->prepare($teachersListQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$teachersList = $stmt->get_result();

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Principal Dashboard - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #4338ca;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #4338ca;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .welcome-banner {
            background: linear-gradient(135deg, #4338ca, #6366f1);
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            text-align: center;
        }
        .stat-value {
            font-size: 2.5rem;
            font-weight: 600;
            color: #4338ca;
            margin-bottom: 0.5rem;
        }
        .stat-label {
            color: #6b7280;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .chart-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            margin: 0.25rem;
        }
        .btn-primary {
            background: #4338ca;
            color: white;
        }
        .btn-primary:hover {
            background: #3730a3;
        }
        .btn-success {
            background: #6366f1;
            color: white;
        }
        .btn-success:hover {
            background: #4f46e5;
        }
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        .btn-danger {
            background: #dc2626;
            color: white;
        }
        .btn-danger:hover {
            background: #b91c1c;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 1rem;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
        .action-buttons {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            border-radius: 0.2rem;
        }
        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #212529;
        }
        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #d39e00;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            border-radius: 8px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        .form-group small {
            color: #666;
            font-size: 0.875rem;
        }
        @media (max-width: 768px) {
            .chart-container {
                grid-template-columns: 1fr;
            }
            .modal-content {
                width: 95%;
                margin: 10% auto;
            }
            .action-buttons {
                flex-direction: column;
                gap: 0.25rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="pdashboard.php">Dashboard</a></li>
            <li><a href="manage_students_principal.php">Students</a></li>
            <li><a href="manage_exams.php">Exams</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>Principal of <?php echo htmlspecialchars($schoolData['school_name']); ?></p>
            <p><?php echo htmlspecialchars($schoolData['school_address']); ?></p>
        </div>

        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-value"><?php echo $studentCount; ?></div>
                <div class="stat-label">Total Students</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $teacherCount; ?></div>
                <div class="stat-label">Total Teachers</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $classCount; ?></div>
                <div class="stat-label">Total Classes</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($avgPerformance, 1); ?>%</div>
                <div class="stat-label">Average Performance</div>
            </div>
        </div>

        <div class="chart-container">
            <div class="chart-card">
                <h2>Class-wise Performance</h2>
                <canvas id="performanceChart"></canvas>
            </div>
            <div class="chart-card">
                <h2>Student Distribution</h2>
                <canvas id="distributionChart"></canvas>
            </div>
        </div>

        <div class="card">
            <h2>Class Performance Overview</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Class</th>
                        <th>Students</th>
                        <th>Average Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($class = $classPerformance->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($class['class_name'] . ' ' . $class['division']); ?></td>
                            <td><?php echo $class['student_count']; ?></td>
                            <td><?php echo number_format($class['avg_percentage'] ?? 0, 1); ?>%</td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                <h2>Teachers Overview</h2>
                <div>
                    <button class="btn btn-primary" onclick="openModal('teacherModal')">Add Teacher</button>
                    <button class="btn btn-success" onclick="openModal('classModal')">Add Class</button>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Teacher Name</th>
                        <th>Email</th>
                        <th>Classes</th>
                        <th>Subjects</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($teacher = $teachersList->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($teacher['fullname']); ?></td>
                            <td><?php echo htmlspecialchars($teacher['username']); ?></td>
                            <td><?php echo htmlspecialchars($teacher['classes'] ?? 'Not assigned'); ?></td>
                            <td><?php echo htmlspecialchars($teacher['subjects'] ?? 'Not assigned'); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-sm" style="color: blue;" onclick="editTeacher(<?php echo $teacher['teacher_id']; ?>, '<?php echo htmlspecialchars($teacher['fullname'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($teacher['username'], ENT_QUOTES); ?>')">
                                        Edit
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add/Edit Teacher Modal -->
    <div id="teacherModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('teacherModal')">&times;</span>
            <h2 id="teacherModalTitle">Add New Teacher</h2>
            <form id="teacherForm">
                <input type="hidden" id="teacher_id" name="teacher_id">
                <input type="hidden" id="form_action" name="action" value="add">
                
                <div class="form-group">
                    <label for="fullname">Full Name:</label>
                    <input type="text" id="fullname" name="fullname" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group" id="passwordGroup">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password">
                    <small id="passwordHelp">Leave blank to auto-generate</small>
                </div>
                <div class="form-group">
                    <label for="send_to_email">Send Credentials To (Email):</label>
                    <input type="email" id="send_to_email" name="send_to_email" placeholder="Leave blank to use teacher's email">
                </div>
                <div class="form-group">
                    <label for="classes">Assign Classes:</label>
                    <select id="classes" name="classes[]" multiple style="height: 100px;">
                    </select>
                    <small>Hold Ctrl to select multiple</small>
                </div>
                <div class="form-group">
                    <label for="subjects">Assign Subjects:</label>
                    <select id="subjects" name="subjects[]" multiple style="height: 100px;">
                    </select>
                    <small>Hold Ctrl to select multiple</small>
                </div>
                <div style="display: flex; gap: 1rem; justify-content: space-between;">
                    <button type="submit" class="btn btn-primary" id="submitBtn">Add Teacher</button>
                    <button type="button" class="btn btn-danger" id="deleteBtn" onclick="deleteTeacher()" style="display: none;">Delete Teacher</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Class Modal -->
    <div id="classModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('classModal')">&times;</span>
            <h2>Add New Class</h2>
            <form id="classForm">
                <div class="form-group">
                    <label for="class_name">Class Name:</label>
                    <input type="text" id="class_name" name="class_name" placeholder="e.g., 10th, 12th" required>
                </div>
                <div class="form-group">
                    <label for="division">Division:</label>
                    <input type="text" id="division" name="division" placeholder="e.g., A, B, C" required>
                </div>
                <button type="submit" class="btn btn-success">Add Class</button>
            </form>
        </div>
    </div>

    <script>
        // Performance Chart
        <?php
        $classPerformance->data_seek(0);
        $classLabels = [];
        $performanceData = [];
        while ($class = $classPerformance->fetch_assoc()) {
            $classLabels[] = $class['class_name'] . ' ' . $class['division'];
            $performanceData[] = round($class['avg_percentage'] ?? 0, 1);
        }
        ?>
        
        const performanceCtx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(performanceCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($classLabels); ?>,
                datasets: [{
                    label: 'Average Performance (%)',
                    data: <?php echo json_encode($performanceData); ?>,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        // Distribution Chart
        <?php
        $classPerformance->data_seek(0);
        $distributionData = [];
        while ($class = $classPerformance->fetch_assoc()) {
            $distributionData[] = $class['student_count'];
        }
        ?>
        
        const distributionCtx = document.getElementById('distributionChart').getContext('2d');
        const distributionChart = new Chart(distributionCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($classLabels); ?>,
                datasets: [{
                    data: <?php echo json_encode($distributionData); ?>,
                    backgroundColor: [
                        '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'
                    ],
                    borderWidth: 0,
                    cutout: '60%'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });

        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
            if (modalId === 'teacherModal') {
                loadClassesAndSubjects();
            }
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
            if (modalId === 'teacherModal') {
                resetTeacherForm();
            }
        }

        // Teacher form functions
        function resetTeacherForm() {
            document.getElementById('teacherForm').reset();
            document.getElementById('teacher_id').value = '';
            document.getElementById('form_action').value = 'add';
            document.getElementById('teacherModalTitle').textContent = 'Add New Teacher';
            document.getElementById('submitBtn').textContent = 'Add Teacher';
            document.getElementById('deleteBtn').style.display = 'none';
            document.getElementById('passwordGroup').style.display = 'block';
            document.getElementById('passwordHelp').textContent = 'Leave blank to auto-generate';
        }

        function editTeacher(id, fullname, email) {
            document.getElementById('teacher_id').value = id;
            document.getElementById('form_action').value = 'edit';
            document.getElementById('fullname').value = fullname;
            document.getElementById('email').value = email;
            document.getElementById('teacherModalTitle').textContent = 'Edit Teacher';
            document.getElementById('submitBtn').textContent = 'Update Teacher';
            document.getElementById('deleteBtn').style.display = 'block';
            document.getElementById('passwordGroup').style.display = 'block';
            document.getElementById('passwordHelp').textContent = 'Leave blank to keep current password';
            loadTeacherAssignments(id);
            openModal('teacherModal');
        }

        function loadClassesAndSubjects() {
            fetch('get_classes_subjects.php')
                .then(response => response.json())
                .then(data => {
                    console.log('Classes and Subjects data:', data);
                    
                    const classSelect = document.getElementById('classes');
                    const subjectSelect = document.getElementById('subjects');
                    
                    classSelect.innerHTML = '';
                    subjectSelect.innerHTML = '';
                    
                    if (data.classes && data.classes.length > 0) {
                        data.classes.forEach(cls => {
                            const option = document.createElement('option');
                            option.value = cls.id;
                            option.textContent = cls.class_name + (cls.division ? ' ' + cls.division : '');
                            classSelect.appendChild(option);
                        });
                    } else {
                        const option = document.createElement('option');
                        option.textContent = 'No classes found';
                        classSelect.appendChild(option);
                    }
                    
                    if (data.subjects && data.subjects.length > 0) {
                        data.subjects.forEach(subject => {
                            const option = document.createElement('option');
                            option.value = subject.id;
                            option.textContent = subject.subject_name;
                            subjectSelect.appendChild(option);
                        });
                    } else {
                        const option = document.createElement('option');
                        option.textContent = 'No subjects found';
                        subjectSelect.appendChild(option);
                    }
                })
                .catch(error => {
                    console.error('Error loading data:', error);
                    alert('Error loading classes and subjects. Check console for details.');
                });
        }

        function loadTeacherAssignments(teacherId) {
            fetch(`get_teacher_assignments.php?teacher_id=${teacherId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Select assigned classes
                        const classSelect = document.getElementById('classes');
                        data.assigned_classes.forEach(classId => {
                            const option = classSelect.querySelector(`option[value="${classId}"]`);
                            if (option) option.selected = true;
                        });
                        
                        // Select assigned subjects
                        const subjectSelect = document.getElementById('subjects');
                        data.assigned_subjects.forEach(subjectId => {
                            const option = subjectSelect.querySelector(`option[value="${subjectId}"]`);
                            if (option) option.selected = true;
                        });
                    }
                })
                .catch(error => console.error('Error loading assignments:', error));
        }

        function deleteTeacher() {
            const teacherId = document.getElementById('teacher_id').value;
            if (confirm('Are you sure you want to delete this teacher? This action cannot be undone.')) {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('teacher_id', teacherId);
                
                fetch('manage_teacher.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Teacher deleted successfully!');
                        closeModal('teacherModal');
                        location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
            }
        }

        // Form submission
        document.getElementById('teacherForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const action = formData.get('action');
            
            fetch('manage_teacher.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(action === 'add' ? 'Teacher added successfully!' : 'Teacher updated successfully!');
                    closeModal('teacherModal');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });

        // Class form submission
        document.getElementById('classForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('manage_class.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Class added successfully!');
                    closeModal('classModal');
                    location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                if (event.target === modal) {
                    modal.style.display = 'none';
                    if (modal.id === 'teacherModal') {
                        resetTeacherForm();
                    }
                }
            });
        };

    </script>
</body>
</html>