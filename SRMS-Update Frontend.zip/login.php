<?php
session_start();

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Teacher credentials
    $teacherUser = "Teacher";
    $teacherPass = "teacher123";
    
    // Student credentials
    $studentUser = "Student";
    $studentPass = "student123";
    
    // Check credentials and redirect accordingly
    if ($username === $teacherUser && $password === $teacherPass) {
        $_SESSION['username'] = $username;
        $_SESSION['user_type'] = 'teacher';
        header("Location: tdashboard.php");
        exit();
    } elseif ($username === $studentUser && $password === $studentPass) {
        $_SESSION['username'] = $username;
        $_SESSION['user_type'] = 'student';
        header("Location: sdashboard.php");
        exit();
    } else {
        $error = "Invalid login credentials";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - Canvas RMS</title>

  <!-- Fonts and styles -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet" />

  <style>
    /* Reset and base */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Inter', sans-serif;
      background: #f9fafc;
      color: #333;
      overflow-x: hidden;
    }

    /* Navbar */
    .navbar {
      position: fixed;
      width: 100%;
      top: 0;
      background: rgba(255,255,255,0.9);
      backdrop-filter: blur(8px);
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
      z-index: 1000;
      transition: background 0.3s ease;
    }
    .navbar.scrolled {
      background: rgba(255, 255, 255, 0.8);
    }
    .logo {
      font-weight: 700;
      font-size: 1.5rem;
      color: #2563eb;
      cursor: default;
      user-select: none;
    }
    .nav-links {
      display: flex;
      gap: 1.5rem;
      list-style: none;
      padding: 0;
      margin: 0;
    }
    .nav-links a {
      text-decoration: none;
      color: #333;
      font-weight: 500;
      transition: color 0.3s ease;
    }
    .nav-links a:hover {
      color: #2563eb;
    }

    /* Login Page Styles */
    .login-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      background-color: #f9fafc;
      padding: 2rem;
      margin-top: 80px; /* To avoid overlap with navbar */
    }
    .login-form {
      background: white;
      padding: 2rem;
      border-radius: 16px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      max-width: 400px;
      width: 100%;
      text-align: center;
      opacity: 0;
      transform: translateY(20px);
      animation: fadeInUp 0.5s forwards;
    }
    .login-form input {
      width: 100%;
      padding: 0.75rem;
      margin: 0.5rem 0;
      border: 1px solid #ccc;
      border-radius: 8px;
      transition: border-color 0.3s ease;
    }
    .login-form input:focus {
      border-color: #2563eb;
      outline: none;
    }
    .login-form button {
      background: #2563eb;
      border: none;
      padding: 0.75rem;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
      width: 100%;
      margin-top: 0.5rem;
    }
    .login-form button:hover {
      background: #1e40af;
    }

    /* Form Select Styles */
    .form-select {
      width: 100%;
      padding: 0.75rem;
      margin: 0.5rem 0;
      border: 1px solid #ccc;
      border-radius: 8px;
      transition: border-color 0.3s ease;
      background-color: white;
    }
    .form-select:focus {
      border-color: #2563eb;
      outline: none;
    }
    
    /* Error message style */
    .error-message {
      color: #e53e3e;
      margin-bottom: 1rem;
    }

    /* Animation */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>
<body>
  <!-- Navigation bar -->
  <nav class="navbar">
    <div class="logo">🎓 SRMS</div>
    <ul class="nav-links">
        <li><a href="index.html">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="login.php">Login</a></li>
    </ul>
  </nav>

  <!-- Login Section -->
  <main>
    <section class="login-container">
      <div class="login-form">
        <h2>Login</h2>
        
        <?php if (!empty($error)): ?>
          <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
          <input type="text" name="username" placeholder="Username" required />
          <input type="password" name="password" placeholder="Password" required />
          <button type="submit">Login</button>
        </form>
      </div>
    </section>
  </main>

  <script>
    // Change navbar background on scroll
    window.addEventListener('scroll', () => {
      const navbar = document.querySelector('.navbar');
      if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    });
    
    // No toggle functionality needed
  </script>
</body>
</html>