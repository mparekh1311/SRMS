<?php
// Check if PHPMailer is installed via composer
if (file_exists('vendor/autoload.php')) {
    require 'vendor/autoload.php';
    define('PHPMAILER_AVAILABLE', true);
} else {
    define('PHPMAILER_AVAILABLE', false);
}

function sendCredentialEmail($email, $fullname, $username, $password, $role = 'teacher') {
    if (!PHPMAILER_AVAILABLE) {
        // Fallback: Use PHP's mail() function
        $subject = 'SRMS Login Credentials';
        $message = "
            <h2>Welcome to SRMS</h2>
            <p>Dear {$fullname},</p>
            <p>Your account has been created successfully. Here are your login credentials:</p>
            <div style='background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 15px 0;'>
                <strong>Username:</strong> {$username}<br>
                <strong>Password:</strong> {$password}<br>
                <strong>Role:</strong> " . ucfirst($role) . "
            </div>
            <p>Please login and change your password after first login.</p>
            <p>Login URL: <a href='http://localhost/login.php'>http://localhost/login.php</a></p>
            <br>
            <p>Best regards,<br>SRMS Team</p>
        ";
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: SRMS System <byjus.rajkot@gmail.com>' . "\r\n";
        
        return mail($email, $subject, $message, $headers);
    }
    
    try {
        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
        
        // Disable debug for production, enable for testing
        // $mail->SMTPDebug = 2;
        // $mail->Debugoutput = 'error_log';
        
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'byjus.rajkot@gmail.com';
        $mail->Password   = 'nogh qpsq kwcz lmyu';
        
        // Try alternative port if 587 fails
        // $mail->Port = 465;
        // $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );

        // Recipients
        $mail->setFrom('byjus.rajkot@gmail.com', 'SRMS System');
        $mail->addAddress($email, $fullname);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'SRMS Login Credentials';
        $mail->Body    = "
            <h2>Welcome to SRMS</h2>
            <p>Dear {$fullname},</p>
            <p>Your account has been created successfully. Here are your login credentials:</p>
            <div style='background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 15px 0;'>
                <strong>Username:</strong> {$username}<br>
                <strong>Password:</strong> {$password}<br>
                <strong>Role:</strong> " . ucfirst($role) . "
            </div>
            <p>Please login and change your password after first login.</p>
            <p>Login URL: <a href='http://localhost/login.php'>http://localhost/login.php</a></p>
            <br>
            <p>Best regards,<br>SRMS Team</p>
        ";

        $mail->send();
        return true;
    } catch (\Exception $e) {
        error_log("Email Error: " . $e->getMessage());
        error_log("PHPMailer Error: " . $mail->ErrorInfo);
        return false;
    }
}

function generatePassword($length = 8) {
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    return substr(str_shuffle($chars), 0, $length);
}
?>