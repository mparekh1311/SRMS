<?php
session_start();

// Check if user is logged in as teacher
if (!isset($_SESSION['username']) || $_SESSION['user_type'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

$message = '';
$messageType = '';

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["excel_file"])) {
    $targetDir = "uploads/";
    
    // Create directory if it doesn't exist
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    
    $targetFile = $targetDir . basename($_FILES["excel_file"]["name"]);
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    
    // Check if file is an Excel file
    if ($fileType == "xlsx" || $fileType == "xls" || $fileType == "csv") {
        if (move_uploaded_file($_FILES["excel_file"]["tmp_name"], $targetFile)) {
            $message = "The file " . htmlspecialchars(basename($_FILES["excel_file"]["name"])) . " has been uploaded and processed.";
            $messageType = "success";
            
            // In a real application, you would process the Excel file here
            // For this demo, we'll just show a success message
        } else {
            $message = "Sorry, there was an error uploading your file.";
            $messageType = "error";
        }
    } else {
        $message = "Sorry, only Excel files (XLSX, XLS) and CSV files are allowed.";
        $messageType = "error";
    }
}

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Marks - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .page-header {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #1e40af;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-family: inherit;
            font-size: 1rem;
        }
        .message {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
        }
        .message.success {
            background-color: #e6fffa;
            border-left: 4px solid #38b2ac;
        }
        .message.error {
            background-color: #fff5f5;
            border-left: 4px solid #e53e3e;
        }
        .file-upload {
            position: relative;
            display: inline-block;
            width: 100%;
        }
        .file-upload-label {
            display: block;
            padding: 1rem;
            background: #f3f4f6;
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .file-upload-label:hover {
            background: #e5e7eb;
        }
        .file-upload input[type="file"] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .template-link {
            display: block;
            margin-top: 1rem;
            color: #2563eb;
            text-decoration: none;
        }
        .template-link:hover {
            text-decoration: underline;
        }
        .instructions {
            background-color: #f9fafb;
            padding: 1rem;
            border-radius: 8px;
            margin-top: 2rem;
        }
        .instructions ol {
            margin-left: 1.5rem;
        }
        .instructions li {
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="tdashboard.php">Dashboard</a></li>
            <li><a href="update_marks.php">Update Marks</a></li>
            <li><a href="add_student.php">Add Student</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1>Bulk Upload Marks</h1>
            <p>Upload an Excel file to update multiple student marks at once.</p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <h2>Upload Excel File</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
                <div class="form-group">
                    <div class="file-upload">
                        <label for="excel_file" class="file-upload-label">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                                <polyline points="17 8 12 3 7 8"></polyline>
                                <line x1="12" y1="3" x2="12" y2="15"></line>
                            </svg>
                            <span>Click to select Excel file or drag and drop</span>
                        </label>
                        <input type="file" name="excel_file" id="excel_file" accept=".xlsx, .xls, .csv" required>
                    </div>
                    <a href="templates/marks_template.xlsx" class="template-link" download>Download Excel Template</a>
                </div>
                
                <button type="submit" class="btn">Upload and Process</button>
            </form>
            
            <div class="instructions">
                <h3>Instructions:</h3>
                <ol>
                    <li>Download the Excel template using the link above.</li>
                    <li>Fill in the student marks data without changing the column headers.</li>
                    <li>Save the file and upload it using the form above.</li>
                    <li>The system will process the file and update the marks accordingly.</li>
                    <li>Supported file formats: XLSX, XLS, CSV.</li>
                </ol>
            </div>
        </div>
    </div>

    <script>
        // Display selected filename
        document.getElementById('excel_file').addEventListener('change', function() {
            const fileName = this.files[0].name;
            const label = document.querySelector('.file-upload-label span');
            label.textContent = fileName;
        });
    </script>
</body>
</html>