<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$teacherId = intval($_GET['teacher_id'] ?? 0);

if (empty($teacherId)) {
    echo json_encode(['success' => false, 'message' => 'Teacher ID required']);
    exit;
}

try {
    // Get assigned classes
    $classQuery = "SELECT tcs.class_id FROM Teacher_Class_Subject tcs WHERE tcs.teacher_id = ?";
    $stmt = $conn->prepare($classQuery);
    $stmt->bind_param("i", $teacherId);
    $stmt->execute();
    $classResult = $stmt->get_result();
    
    $assignedClasses = [];
    while ($row = $classResult->fetch_assoc()) {
        $assignedClasses[] = $row['class_id'];
    }
    
    // Get assigned subjects
    $subjectQuery = "SELECT tcs.subject_id FROM Teacher_Class_Subject tcs WHERE tcs.teacher_id = ?";
    $stmt = $conn->prepare($subjectQuery);
    $stmt->bind_param("i", $teacherId);
    $stmt->execute();
    $subjectResult = $stmt->get_result();
    
    $assignedSubjects = [];
    while ($row = $subjectResult->fetch_assoc()) {
        $assignedSubjects[] = $row['subject_id'];
    }
    
    echo json_encode([
        'success' => true,
        'assigned_classes' => array_unique($assignedClasses),
        'assigned_subjects' => array_unique($assignedSubjects)
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>