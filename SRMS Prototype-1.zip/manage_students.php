<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

// Get all students with their details
$studentsQuery = "
    SELECT s.student_id, s.roll_number, u.fullname, c.class_name, c.division, sc.school_name
    FROM Student s
    JOIN User u ON s.user_id = u.user_id
    JOIN Class c ON s.class_id = c.class_id
    JOIN School sc ON s.school_id = sc.school_id
    ORDER BY sc.school_name, c.class_name, c.division, s.roll_number
";
$studentsResult = $conn->query($studentsQuery);

$message = '';
$messageType = '';

// Handle student deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $studentId = $_GET['delete'];
    
    // Get user_id for the student
    $userIdQuery = "SELECT user_id FROM Student WHERE student_id = ?";
    $stmt = $conn->prepare($userIdQuery);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $userId = $result->fetch_assoc()['user_id'];
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Delete results for this student
            $deleteResultsQuery = "DELETE FROM result WHERE student_id = ?";
            $stmt = $conn->prepare($deleteResultsQuery);
            $stmt->bind_param("i", $studentId);
            $stmt->execute();
            
            // Delete student record
            $deleteStudentQuery = "DELETE FROM Student WHERE student_id = ?";
            $stmt = $conn->prepare($deleteStudentQuery);
            $stmt->bind_param("i", $studentId);
            $stmt->execute();
            
            // Delete user record
            $deleteUserQuery = "DELETE FROM User WHERE user_id = ?";
            $stmt = $conn->prepare($deleteUserQuery);
            $stmt->bind_param("i", $userId);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            $message = "Student deleted successfully.";
            $messageType = "success";
            
            // Refresh the page to update the list
            header("Location: manage_students.php?msg=deleted");
            exit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $message = "Error deleting student: " . $e->getMessage();
            $messageType = "error";
        }
    }
}

// Set message from URL parameter
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'added':
            $message = "Student added successfully.";
            $messageType = "success";
            break;
        case 'updated':
            $message = "Student updated successfully.";
            $messageType = "success";
            break;
        case 'deleted':
            $message = "Student deleted successfully.";
            $messageType = "success";
            break;
    }
}

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .page-header {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
        }
        .btn:hover {
            background: #1e40af;
        }
        .btn-white {
            background: white;
            color: #2563eb;
        }
        .btn-white:hover {
            background: #f3f4f6;
        }
        .students-table {
            width: 100%;
            border-collapse: collapse;
        }
        .students-table th, .students-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .students-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .action-link {
            color: #2563eb;
            text-decoration: none;
            margin-right: 1rem;
        }
        .action-link:hover {
            text-decoration: underline;
        }
        .delete-link {
            color: #e53e3e;
        }
        .message {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
        }
        .message.success {
            background-color: #e6fffa;
            border-left: 4px solid #38b2ac;
        }
        .message.error {
            background-color: #fff5f5;
            border-left: 4px solid #e53e3e;
        }
        .search-box {
            margin-bottom: 1.5rem;
            display: flex;
            gap: 1rem;
        }
        .search-box input {
            flex: 1;
            padding: 0.75rem;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-family: inherit;
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="manage_students.php">Manage Students</a></li>
            <li><a href="manage_teachers.php">Manage Teachers</a></li>
            <li><a href="manage_classes.php">Manage Classes</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1>Manage Students</h1>
                <p>Add, edit, or remove students from the system.</p>
            </div>
            <a href="add_student.php" class="btn btn-white">Add New Student</a>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="search-box">
                <input type="text" id="searchInput" placeholder="Search by name, roll number, class, or school...">
                <button class="btn" onclick="searchStudents()">Search</button>
            </div>

            <table class="students-table" id="studentsTable">
                <thead>
                    <tr>
                        <th>Roll Number</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>School</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($studentsResult->num_rows > 0): ?>
                        <?php while ($student = $studentsResult->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                                <td><?php echo htmlspecialchars($student['fullname']); ?></td>
                                <td><?php echo htmlspecialchars($student['class_name'] . ' ' . $student['division']); ?></td>
                                <td><?php echo htmlspecialchars($student['school_name']); ?></td>
                                <td>
                                    <a href="view_student.php?id=<?php echo $student['student_id']; ?>" class="action-link">View</a>
                                    <a href="edit_student.php?id=<?php echo $student['student_id']; ?>" class="action-link">Edit</a>
                                    <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $student['student_id']; ?>, '<?php echo htmlspecialchars($student['fullname']); ?>')" class="action-link delete-link">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center;">No students found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function confirmDelete(studentId, studentName) {
            if (confirm(`Are you sure you want to delete ${studentName}? This action cannot be undone.`)) {
                window.location.href = `manage_students.php?delete=${studentId}`;
            }
        }

        function searchStudents() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toUpperCase();
            const table = document.getElementById('studentsTable');
            const rows = table.getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) {
                let found = false;
                const cells = rows[i].getElementsByTagName('td');
                
                for (let j = 0; j < cells.length - 1; j++) {
                    const cellText = cells[j].textContent || cells[j].innerText;
                    if (cellText.toUpperCase().indexOf(filter) > -1) {
                        found = true;
                        break;
                    }
                }
                
                rows[i].style.display = found ? '' : 'none';
            }
        }
    </script>
</body>
</html>