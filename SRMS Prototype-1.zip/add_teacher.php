<?php
session_start();
require_once 'db_connect.php';
require_once 'email_config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $sendToEmail = trim($_POST['send_to_email'] ?? $email);
    $classes = $_POST['classes'] ?? [];
    $subjects = $_POST['subjects'] ?? [];
    $schoolId = $_SESSION['school_id'];
    
    // Generate credentials
    $username = $email;
    $password = generatePassword();
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    try {
        $conn->begin_transaction();
        
        // Insert into User table
        $userQuery = "INSERT INTO User (username, password, fullname, role, school_id) VALUES (?, ?, ?, 'teacher', ?)";
        $stmt = $conn->prepare($userQuery);
        $stmt->bind_param("sssi", $username, $hashedPassword, $fullname, $schoolId);
        $stmt->execute();
        $userId = $conn->insert_id;
        
        // Insert into Teacher table
        $teacherQuery = "INSERT INTO Teacher (user_id, school_id) VALUES (?, ?)";
        $stmt = $conn->prepare($teacherQuery);
        $stmt->bind_param("ii", $userId, $schoolId);
        $stmt->execute();
        $teacherId = $conn->insert_id;
        
        // Assign classes and subjects
        if (!empty($classes) && !empty($subjects)) {
            $assignQuery = "INSERT INTO Teacher_Class_Subject (teacher_id, class_id, subject_id) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($assignQuery);
            
            foreach ($classes as $classId) {
                foreach ($subjects as $subjectId) {
                    $stmt->bind_param("iii", $teacherId, $classId, $subjectId);
                    $stmt->execute();
                }
            }
        }
        
        $conn->commit();
        
        // Send email
        if (sendCredentialEmail($sendToEmail, $fullname, $username, $password)) {
            $response['success'] = true;
            $response['message'] = 'Teacher added successfully and credentials sent to ' . $sendToEmail;
        } else {
            $response['success'] = true;
            $response['message'] = 'Teacher added successfully but email failed. Credentials: ' . $username . ' / ' . $password;
        }
        
    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = 'Error adding teacher: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>