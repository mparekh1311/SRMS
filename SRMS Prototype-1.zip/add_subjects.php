<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    die('Unauthorized access');
}

$subjects = [
    'Mathematics', 'English', 'Science', 'Physics', 'Chemistry', 'Biology',
    'History', 'Geography', 'Computer Science', 'Physical Education',
    'Art', 'Music', 'Economics', 'Sociology', 'Psychology', 'Philosophy',
    'Literature', 'Foreign Language', 'Business Studies', 'Accounting'
];

$schoolId = $_SESSION['school_id'];
$added = 0;

foreach ($subjects as $subject) {
    // Check if subject already exists
    $checkStmt = $conn->prepare("SELECT subject_id FROM Subject WHERE subject_name = ? AND school_id = ?");
    $checkStmt->bind_param("si", $subject, $schoolId);
    $checkStmt->execute();
    
    if ($checkStmt->get_result()->num_rows == 0) {
        // Insert subject
        $insertStmt = $conn->prepare("INSERT INTO Subject (subject_name, school_id) VALUES (?, ?)");
        $insertStmt->bind_param("si", $subject, $schoolId);
        if ($insertStmt->execute()) {
            $added++;
        }
    }
}

echo "Added $added subjects successfully!";
?>