<?php
require_once 'email_config.php';

// Test email sending
$testEmail = 'test@example.com'; // Change this to your test email
$result = sendCredentialEmail($testEmail, 'Test User', 'testuser@example.com', 'testpass123');

if ($result) {
    echo "Email sent successfully!";
} else {
    echo "Email failed to send. Check error logs.";
}

// Also test basic PHP mail function
echo "<br><br>Testing PHP mail() function:<br>";
$subject = "Test Email";
$message = "This is a test email from SRMS";
$headers = "From: byjus.rajkot@gmail.com";

if (mail($testEmail, $subject, $message, $headers)) {
    echo "PHP mail() function works!";
} else {
    echo "PHP mail() function failed.";
}
?>