<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$schoolId = $_SESSION['school_id'];

// Get exams for this school from Exam table - only Term 1 and Term 2
$examsQuery = "
    SELECT e.exam_id, e.exam_name, e.total_marks, e.exam_date,
           c.class_name, c.division, sub.subject_name, 
           e.class_id, e.subject_id
    FROM Exam e
    JOIN Class c ON e.class_id = c.class_id
    JOIN Subject sub ON e.subject_id = sub.subject_id
    WHERE e.school_id = ? AND e.exam_name IN ('term1', 'term2')
    ORDER BY c.class_name, sub.subject_name, e.exam_name
";
$stmt = $conn->prepare($examsQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$examsResult = $stmt->get_result();

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Exams - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #4338ca;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #4338ca;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .page-header {
            background: linear-gradient(135deg, #4338ca, #6366f1);
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        .btn {
            display: inline-block;
            background: #4338ca;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
            margin: 0.25rem;
        }
        .btn:hover {
            background: #3730a3;
        }
        .btn-white {
            background: white;
            color: #4338ca;
        }
        .btn-danger {
            background: #dc2626;
        }
        .btn-danger:hover {
            background: #b91c1c;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 1rem;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="pdashboard.php">Dashboard</a></li>
            <li><a href="manage_students_principal.php">Students</a></li>
            <li><a href="manage_exams.php">Exams</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1>Manage Exams</h1>
                <p>Create and manage exam structure</p>
            </div>
            <button class="btn btn-white" onclick="openModal('examModal')">Create Exam</button>
        </div>

        <div class="card">
            <h2>Exams List</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Exam Name</th>
                        <th>Class</th>
                        <th>Subject</th>
                        <th>Exam Date</th>
                        <th>Total Marks</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($exam = $examsResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo ucfirst(str_replace('term', 'Term ', $exam['exam_name'])); ?></td>
                            <td><?php echo htmlspecialchars($exam['class_name'] . ' ' . $exam['division']); ?></td>
                            <td><?php echo htmlspecialchars($exam['subject_name']); ?></td>
                            <td><?php echo htmlspecialchars($exam['exam_date']); ?></td>
                            <td><?php echo htmlspecialchars($exam['total_marks']); ?></td>
                            <td>
                                <button class="btn" onclick="editExam(<?php echo $exam['exam_id']; ?>, '<?php echo $exam['exam_date']; ?>', <?php echo $exam['total_marks']; ?>)">Edit</button>
                                <button class="btn btn-danger" onclick="deleteExam(<?php echo $exam['exam_id']; ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Create Exam Modal -->
    <div id="examModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('examModal')">&times;</span>
            <h2>Create New Exam</h2>
            <form id="examForm">
                <div class="form-group">
                    <label for="exam_name">Exam Name:</label>
                    <select id="exam_name" name="exam_name" required>
                        <option value="">Select Exam</option>
                        <option value="term1">Term 1</option>
                        <option value="term2">Term 2</option>
                        <option value="custom">Custom (Principal Only)</option>
                    </select>
                </div>
                <div class="form-group" id="custom_exam_group" style="display: none;">
                    <label for="custom_exam_name">Custom Exam Name:</label>
                    <input type="text" id="custom_exam_name" name="custom_exam_name">
                </div>
                <div class="form-group">
                    <label for="class_id">Class:</label>
                    <select id="class_id" name="class_id" required>
                    </select>
                </div>
                <div class="form-group">
                    <label for="subject_id">Subject:</label>
                    <select id="subject_id" name="subject_id" required>
                    </select>
                </div>
                <div class="form-group">
                    <label for="exam_date">Exam Date:</label>
                    <input type="date" id="exam_date" name="exam_date" required>
                </div>
                <div class="form-group">
                    <label for="total_marks">Total Marks:</label>
                    <input type="number" id="total_marks" name="total_marks" required>
                </div>
                <button type="submit" class="btn">Create Exam</button>
            </form>
        </div>
    </div>

    <!-- Edit Exam Modal -->
    <div id="editExamModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editExamModal')">&times;</span>
            <h2>Edit Exam</h2>
            <form id="editExamForm">
                <input type="hidden" id="edit_exam_id" name="exam_id">
                <div class="form-group">
                    <label for="edit_exam_date">Exam Date:</label>
                    <input type="date" id="edit_exam_date" name="exam_date" required>
                </div>
                <div class="form-group">
                    <label for="edit_total_marks">Total Marks:</label>
                    <input type="number" id="edit_total_marks" name="total_marks" required>
                </div>
                <button type="submit" class="btn">Update Exam</button>
            </form>
        </div>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
            if (modalId === 'examModal') {
                loadClassesAndSubjects();
            }
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function loadClassesAndSubjects() {
            fetch('get_classes_subjects.php')
            .then(response => response.json())
            .then(data => {
                const classSelect = document.getElementById('class_id');
                const subjectSelect = document.getElementById('subject_id');
                
                classSelect.innerHTML = '<option value="">Select Class</option>';
                subjectSelect.innerHTML = '<option value="">Select Subject</option>';
                
                data.classes.forEach(cls => {
                    const option = document.createElement('option');
                    option.value = cls.class_id;
                    option.textContent = cls.class_name;
                    classSelect.appendChild(option);
                });
                
                data.subjects.forEach(subject => {
                    const option = document.createElement('option');
                    option.value = subject.subject_id;
                    option.textContent = subject.subject_name;
                    subjectSelect.appendChild(option);
                });
            });
        }

        document.getElementById('exam_name').addEventListener('change', function() {
            const customGroup = document.getElementById('custom_exam_group');
            if (this.value === 'custom') {
                customGroup.style.display = 'block';
                document.getElementById('custom_exam_name').required = true;
            } else {
                customGroup.style.display = 'none';
                document.getElementById('custom_exam_name').required = false;
            }
        });

        document.getElementById('examForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('create_exam.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('examModal');
                    location.reload();
                }
            });
        });

        function editExam(examId, currentDate, currentMarks) {
            document.getElementById('edit_exam_id').value = examId;
            document.getElementById('edit_exam_date').value = currentDate;
            document.getElementById('edit_total_marks').value = currentMarks;
            openModal('editExamModal');
        }

        function deleteExam(examId) {
            if (confirm('Are you sure you want to delete this exam? This will remove all related results.')) {
                const formData = new FormData();
                formData.append('exam_id', examId);
                
                fetch('delete_exam.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) {
                        location.reload();
                    }
                });
            }
        }

        document.getElementById('editExamForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('update_exam.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('editExamModal');
                    location.reload();
                }
            });
        });

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>