<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $examName = $_POST['exam_name'];
    $customExamName = $_POST['custom_exam_name'] ?? '';
    $classId = $_POST['class_id'];
    $subjectId = $_POST['subject_id'];
    $examDate = $_POST['exam_date'];
    $totalMarks = $_POST['total_marks'];
    $schoolId = $_SESSION['school_id'];
    
    // Determine final exam name
    if ($examName === 'custom') {
        if (empty($customExamName)) {
            $response['message'] = 'Custom exam name is required.';
            header('Content-Type: application/json');
            echo json_encode($response);
            exit();
        }
        $finalExamName = $customExamName;
    } else {
        $finalExamName = ucfirst($examName); // "term1" becomes "Term1"
    }
    
    try {
        // Check if exam already exists for this class-subject combination
        $checkQuery = "SELECT * FROM Exam WHERE class_id = ? AND subject_id = ? AND exam_name = ? AND school_id = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("iisi", $classId, $subjectId, $finalExamName, $schoolId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $response['message'] = 'Exam already exists for this class and subject.';
        } else {
            $insertQuery = "INSERT INTO Exam (exam_name, exam_date, total_marks, school_id, class_id, subject_id) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("ssdiiii", $finalExamName, $examDate, $totalMarks, $schoolId, $classId, $subjectId);
            $stmt->execute();
            
            $response['success'] = true;
            $response['message'] = 'Exam created successfully!';
        }
        
    } catch (Exception $e) {
        $response['message'] = 'Error creating exam: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>