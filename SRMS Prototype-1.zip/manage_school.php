<?php
session_start();
require_once 'db_connect.php';
// Check if user is logged in as admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$message = '';
$messageType = '';
$schoolData = null;
$principalData = null;
$isEdit = false;
$showCredentials = false;

// Function to generate username from name and role
function generateUsername($fullname, $role) {
    $nameParts = explode(' ', strtolower(trim($fullname)));
    $firstName = $nameParts[0];
    $lastName = isset($nameParts[1]) ? $nameParts[1] : '';
    return $firstName . '.' . $role . ($lastName ? substr($lastName, 0, 3) : '');
}

// Function to generate password
function generatePassword($length = 8) {
    return substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, $length);
}

// Handle delete school
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $schoolId = $_GET['delete'];
    
    $conn->begin_transaction();
    try {
        // Delete all related data
        $conn->query("DELETE FROM Result WHERE student_id IN (SELECT student_id FROM Student WHERE school_id = $schoolId)");
        $conn->query("DELETE FROM Teacher_Class_Subject WHERE teacher_id IN (SELECT teacher_id FROM Teacher WHERE school_id = $schoolId)");
        $conn->query("DELETE FROM Student WHERE school_id = $schoolId");
        $conn->query("DELETE FROM Teacher WHERE school_id = $schoolId");
        $conn->query("DELETE FROM User WHERE school_id = $schoolId");
        $conn->query("DELETE FROM Subject WHERE school_id = $schoolId");
        $conn->query("DELETE FROM Class WHERE school_id = $schoolId");
        $conn->query("DELETE FROM School WHERE school_id = $schoolId");
        
        $conn->commit();
        header("Location: admin_dashboard.php?msg=school_deleted");
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error deleting school: " . $e->getMessage();
        $messageType = "error";
    }
}

// Check if editing existing school
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $schoolId = $_GET['id'];
    $isEdit = true;
    
    // Get school data
    $query = "SELECT * FROM School WHERE school_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $schoolId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $schoolData = $result->fetch_assoc();
        
        // Get principal data if exists
        $principalQuery = "SELECT * FROM User WHERE role = 'principal' AND school_id = ?";
        $stmt = $conn->prepare($principalQuery);
        $stmt->bind_param("i", $schoolId);
        $stmt->execute();
        $principalResult = $stmt->get_result();
        
        if ($principalResult->num_rows > 0) {
            $principalData = $principalResult->fetch_assoc();
        }
    } else {
        $message = "School not found.";
        $messageType = "error";
    }
}

// Handle share credentials
if (isset($_POST['share_credentials']) && $principalData) {
    // In a real application, you would send an email here
    $message = "Credentials would be sent to: " . $principalData['username'] . " (Password: " . $principalData['password'] . ")";
    $messageType = "success";
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['share_credentials'])) {
    $schoolName = $_POST['school_name'];
    $schoolAddress = $_POST['school_address'];
    $principalName = $_POST['principal_name'] ?? '';
    $principalEmail = $_POST['principal_email'] ?? '';
    $principalContact = $_POST['principal_contact'] ?? '';
    
    $conn->begin_transaction();
    
    try {
        if ($isEdit && isset($_POST['school_id'])) {
            // Update existing school
            $schoolId = $_POST['school_id'];
            $updateQuery = "UPDATE School SET school_name = ?, school_address = ? WHERE school_id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("ssi", $schoolName, $schoolAddress, $schoolId);
            $stmt->execute();
            
            // Update or add principal
            if ($principalName && $principalEmail) {
                if ($principalData) {
                    // Update existing principal
                    $updateUserQuery = "UPDATE User SET fullname = ?, username = ? WHERE user_id = ?";
                    $stmt = $conn->prepare($updateUserQuery);
                    $stmt->bind_param("ssi", $principalName, $principalEmail, $principalData['user_id']);
                    $stmt->execute();
                } else {
                    // Add new principal
                    $username = $principalEmail;
                    $password = generatePassword();
                    
                    $insertUserQuery = "INSERT INTO User (username, password, fullname, role, school_id) VALUES (?, ?, ?, 'principal', ?)";
                    $stmt = $conn->prepare($insertUserQuery);
                    $stmt->bind_param("sssi", $username, $password, $principalName, $schoolId);
                    $stmt->execute();
                }
            }
        } else {
            // Add new school
            $insertQuery = "INSERT INTO School (school_name, school_address) VALUES (?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("ss", $schoolName, $schoolAddress);
            $stmt->execute();
            $schoolId = $conn->insert_id;
            
            // Add principal if provided
            if ($principalName && $principalEmail) {
                $username = $principalEmail;
                $password = generatePassword();
                
                $insertUserQuery = "INSERT INTO User (username, password, fullname, role, school_id) VALUES (?, ?, ?, 'principal', ?)";
                $stmt = $conn->prepare($insertUserQuery);
                $stmt->bind_param("sssi", $username, $password, $principalName, $schoolId);
                $stmt->execute();
                $showCredentials = true;
            }
        }
        
        $conn->commit();
        $message = $isEdit ? "School updated successfully!" : "School added successfully!";
        $messageType = "success";
        
        // Get principal data for new school
        if (!$isEdit && $principalName && $principalEmail) {
            $principalQuery = "SELECT * FROM User WHERE role = 'principal' AND school_id = ?";
            $stmt = $conn->prepare($principalQuery);
            $stmt->bind_param("i", $schoolId);
            $stmt->execute();
            $principalResult = $stmt->get_result();
            
            if ($principalResult->num_rows > 0) {
                $principalData = $principalResult->fetch_assoc();
            }
        }
        
        // Refresh data if editing
        if ($isEdit) {
            $query = "SELECT * FROM School WHERE school_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $schoolId);
            $stmt->execute();
            $result = $stmt->get_result();
            $schoolData = $result->fetch_assoc();
            
            $principalQuery = "SELECT * FROM User WHERE role = 'principal' AND school_id = ?";
            $stmt = $conn->prepare($principalQuery);
            $stmt->bind_param("i", $schoolId);
            $stmt->execute();
            $principalResult = $stmt->get_result();
            
            if ($principalResult->num_rows > 0) {
                $principalData = $principalResult->fetch_assoc();
            }
        }
        
    } catch (Exception $e) {
        $conn->rollback();
        $message = "Error: " . $e->getMessage();
        $messageType = "error";
    }
}

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $isEdit ? 'Edit School' : 'Add School'; ?> - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .page-header {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
            margin-right: 1rem;
        }
        .btn:hover {
            background: #1e40af;
        }
        .btn-secondary {
            background: #6b7280;
        }
        .btn-secondary:hover {
            background: #4b5563;
        }
        .btn-success {
            background: #10b981;
        }
        .btn-success:hover {
            background: #059669;
        }
        .btn-danger {
            background: #e53e3e;
        }
        .btn-danger:hover {
            background: #dc2626;
        }
        .form-group {
            margin-bottom: 1.5rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-family: inherit;
            font-size: 1rem;
        }
        .form-row {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        .message {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
        }
        .message.success {
            background-color: #e6fffa;
            border-left: 4px solid #38b2ac;
        }
        .message.error {
            background-color: #fff5f5;
            border-left: 4px solid #e53e3e;
        }
        .required::after {
            content: " *";
            color: #e53e3e;
        }
        .credentials-info {
            background: #f8fafc;
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1rem;
        }
        .section-divider {
            border-top: 1px solid #e5e7eb;
            margin: 2rem 0;
            padding-top: 2rem;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1><?php echo $isEdit ? 'Edit School' : 'Add New School'; ?></h1>
            <p><?php echo $isEdit ? 'Update school information.' : 'Create a new school in the system.'; ?></p>
        </div>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . ($isEdit ? '?id=' . $schoolData['school_id'] : ''); ?>">
                <?php if ($isEdit): ?>
                    <input type="hidden" name="school_id" value="<?php echo $schoolData['school_id']; ?>">
                <?php endif; ?>
                
                <h2>School Information</h2>
                
                <div class="form-group">
                    <label for="school_name" class="required">School Name</label>
                    <input type="text" name="school_name" id="school_name" class="form-control" 
                           value="<?php echo $schoolData ? htmlspecialchars($schoolData['school_name']) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="school_address" class="required">School Address</label>
                    <textarea name="school_address" id="school_address" class="form-control" rows="4" required><?php echo $schoolData ? htmlspecialchars($schoolData['school_address']) : ''; ?></textarea>
                </div>
                
                <div class="section-divider">
                    <h2>Principal Information</h2>
                </div>
                
                <div class="form-group">
                    <label for="principal_name">Principal Full Name</label>
                    <input type="text" name="principal_name" id="principal_name" class="form-control" 
                           value="<?php echo $principalData ? htmlspecialchars($principalData['fullname']) : ''; ?>">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="principal_email">Principal Email ID</label>
                        <input type="email" name="principal_email" id="principal_email" class="form-control" 
                               value="<?php echo $principalData ? htmlspecialchars($principalData['username']) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="principal_contact">Contact Number</label>
                        <input type="tel" name="principal_contact" id="principal_contact" class="form-control">
                    </div>
                </div>
                
                <?php if ($principalData || $showCredentials): ?>
                    <div class="credentials-info">
                        <h4>Login Credentials</h4>
                        <p><strong>Username:</strong> <?php echo htmlspecialchars($principalData['username']); ?></p>
                        <p><strong>Password:</strong> <?php echo htmlspecialchars($principalData['password']); ?></p>
                    </div>
                <?php endif; ?>
                
                <div style="margin-top: 2rem;">
                    <button type="submit" class="btn"><?php echo $isEdit ? 'Update School' : 'Add School'; ?></button>
                    <?php if ($principalData || $showCredentials): ?>
                        <button type="submit" name="share_credentials" class="btn btn-success">Share Credentials</button>
                    <?php endif; ?>
                    <?php if ($isEdit): ?>
                        <button type="button" onclick="confirmDelete()" class="btn btn-danger">Delete School</button>
                    <?php endif; ?>
                    <a href="admin_dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <script>
        function confirmDelete() {
            if (confirm('Are you sure you want to delete this school? This will remove all associated data including students, teachers, and results. This action cannot be undone.')) {
                window.location.href = '<?php echo $_SERVER["PHP_SELF"]; ?>?delete=<?php echo $schoolData["school_id"]; ?>';
            }
        }
    </script>
</body>
</html>