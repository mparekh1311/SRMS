<?php
session_start();
require_once 'db_connect.php';

// Check if user is logged in as teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    header("Location: login.php");
    exit();
}

// Get teacher information
$teacherId = 0;
$query = "SELECT t.teacher_id FROM Teacher t WHERE t.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $teacherId = $row['teacher_id'];
}

// Get classes and subjects taught by this teacher
$classesQuery = "
    SELECT c.class_id, c.class_name, c.division, s.subject_id, s.subject_name
    FROM Teacher_Class_Subject tcs
    JOIN Class c ON tcs.class_id = c.class_id
    JOIN Subject s ON tcs.subject_id = s.subject_id
    WHERE tcs.teacher_id = ?
    ORDER BY c.class_name, c.division
";
$stmt = $conn->prepare($classesQuery);
$stmt->bind_param("i", $teacherId);
$stmt->execute();
$classesResult = $stmt->get_result();

$teacherClasses = [];
while ($row = $classesResult->fetch_assoc()) {
    $classId = $row['class_id'];
    if (!isset($teacherClasses[$classId])) {
        $teacherClasses[$classId] = [
            'class_name' => $row['class_name'],
            'division' => $row['division'],
            'subjects' => []
        ];
    }
    $teacherClasses[$classId]['subjects'][] = [
        'subject_id' => $row['subject_id'],
        'subject_name' => $row['subject_name']
    ];
}

// Get student results for classes taught by this teacher
$studentResults = [];
if (!empty($teacherClasses)) {
    $classIds = array_keys($teacherClasses);
    
    foreach ($classIds as $classId) {
        $resultsQuery = "
            SELECT s.student_id, u.fullname as student_name, s.roll_number,
                   sub.subject_id, sub.subject_name, 
                   r.exam_term, r.marks_obtained, r.total_subject_marks
            FROM Student s
            JOIN User u ON s.user_id = u.user_id
            JOIN Result r ON s.student_id = r.student_id
            JOIN Subject sub ON r.subject_id = sub.subject_id
            WHERE r.class_id = ? AND r.recorded_by_teacher_id = ?
            ORDER BY s.roll_number, sub.subject_name, r.exam_term
        ";
        $stmt = $conn->prepare($resultsQuery);
        $stmt->bind_param("ii", $classId, $teacherId);
        $stmt->execute();
        $resultsResult = $stmt->get_result();
        
        while ($row = $resultsResult->fetch_assoc()) {
            $studentId = $row['student_id'];
            $subjectId = $row['subject_id'];
            $examTerm = $row['exam_term'];
            
            if (!isset($studentResults[$classId])) {
                $studentResults[$classId] = [];
            }
            
            if (!isset($studentResults[$classId][$studentId])) {
                $studentResults[$classId][$studentId] = [
                    'student_name' => $row['student_name'],
                    'roll_number' => $row['roll_number'],
                    'subjects' => []
                ];
            }
            
            if (!isset($studentResults[$classId][$studentId]['subjects'][$subjectId])) {
                $studentResults[$classId][$studentId]['subjects'][$subjectId] = [
                    'subject_name' => $row['subject_name'],
                    'terms' => []
                ];
            }
            
            $studentResults[$classId][$studentId]['subjects'][$subjectId]['terms'][$examTerm] = [
                'marks_obtained' => $row['marks_obtained'],
                'total_marks' => $row['total_subject_marks'],
                'percentage' => ($row['marks_obtained'] / $row['total_subject_marks']) * 100
            ];
        }
    }
}

// Calculate statistics for charts
$subjectAverages = [];
$gradeDistribution = [
    'A+' => 0,
    'A' => 0,
    'B' => 0,
    'C' => 0,
    'D' => 0,
    'F' => 0
];

foreach ($studentResults as $classId => $students) {
    foreach ($students as $studentId => $studentData) {
        foreach ($studentData['subjects'] as $subjectId => $subjectData) {
            foreach ($subjectData['terms'] as $term => $termData) {
                $subjectName = $subjectData['subject_name'];
                $percentage = $termData['percentage'];
                
                // Calculate subject averages
                if (!isset($subjectAverages[$subjectName])) {
                    $subjectAverages[$subjectName] = [
                        'total' => 0,
                        'count' => 0
                    ];
                }
                $subjectAverages[$subjectName]['total'] += $percentage;
                $subjectAverages[$subjectName]['count']++;
                
                // Calculate grade distribution
                if ($percentage >= 90) $gradeDistribution['A+']++;
                elseif ($percentage >= 80) $gradeDistribution['A']++;
                elseif ($percentage >= 70) $gradeDistribution['B']++;
                elseif ($percentage >= 60) $gradeDistribution['C']++;
                elseif ($percentage >= 50) $gradeDistribution['D']++;
                else $gradeDistribution['F']++;
            }
        }
    }
}

// Calculate final averages
$finalSubjectAverages = [];
foreach ($subjectAverages as $subject => $data) {
    if ($data['count'] > 0) {
        $finalSubjectAverages[$subject] = round($data['total'] / $data['count'], 1);
    }
}

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .welcome-banner {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);up
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .charts-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .chart-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        .student-card {
            margin-bottom: 2rem;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 1rem;
        }
        .student-card:last-child {
            border-bottom: none;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .marks-table th, .marks-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .marks-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .btn {
            display: inline-block;
            background: #2563eb;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
            margin-right: 0.5rem;
        }
        .btn:hover {
            background: #1e40af;
        }
        .edit-link {
            color: #2563eb;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .edit-link:hover {
            text-decoration: underline;
        }
        .assignments-section {
            background: #f8fafc;
            padding: 1rem;
            border-radius: 8px;
            margin-top: 1rem;
        }
        .assignment-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e2e8f0;
        }
        .assignment-item:last-child {
            border-bottom: none;
        }         background: #1e40af;
        }
        .btn-secondary {
            background: #6b7280;
        }
        .btn-secondary:hover {
            background: #4b5563;
        }
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
        }
        .btn-success {
            background: #10b981;
        }
        .btn-success:hover {
            background: #059669;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 12px;
            width: 90%;
            max-width: 800px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 1rem;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
        .marks-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1rem;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        .upload-area {
            border: 2px dashed #d1d5db;
            border-radius: 8px;
            padding: 2rem;
            text-align: center;
            margin: 1rem 0;
        }
        .assignments-table {
            width: 100%;
            border-collapse: collapse;
        }
        .assignments-table th, .assignments-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .assignments-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .class-section {
            margin-bottom: 2rem;
        }
        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="tdashboard.php">Dashboard</a></li>
            <li><a href="update_marks.php">Update Marks</a></li>
            <li><a href="upload_marks.php">Upload Marks</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>Manage student marks and academic performance.</p>
        </div>



        <?php if (!empty($finalSubjectAverages) && !empty($gradeDistribution)): ?>
        <div class="charts-container">
            <div class="chart-card">
                <h2>Subject Averages</h2>
                <canvas id="barChart"></canvas>
            </div>
            <div class="chart-card">
                <h2>Grade Distribution</h2>
                <canvas id="pieChart"></canvas>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($teacherClasses)): ?>
        <div class="card">
            <h2>Manage Marks</h2>
            <div class="assignments-section">
                <?php foreach ($teacherClasses as $classId => $classData): ?>
                    <?php foreach ($classData['subjects'] as $subject): ?>
                        <div class="assignment-item">
                            <span><?php echo htmlspecialchars($classData['class_name'] . ' ' . $classData['division'] . ' - ' . $subject['subject_name']); ?></span>
                            <div>
                                <a href="#" class="edit-link" onclick="openMarksModal(<?php echo $classId; ?>, <?php echo $subject['subject_id']; ?>, '<?php echo htmlspecialchars($classData['class_name'] . ' ' . $classData['division']); ?>', '<?php echo htmlspecialchars($subject['subject_name']); ?>')">Edit</a> | 
                                <a href="#" class="edit-link" onclick="openUploadModal(<?php echo $classId; ?>, <?php echo $subject['subject_id']; ?>)">Upload</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($teacherClasses)): ?>
            <?php foreach ($teacherClasses as $classId => $classData): ?>
                <div class="card class-section">
                    <h2>Class <?php echo htmlspecialchars($classData['class_name'] . ' ' . $classData['division']); ?></h2>
                    
                    <?php if (isset($studentResults[$classId]) && !empty($studentResults[$classId])): ?>
                        <?php foreach ($studentResults[$classId] as $studentId => $studentData): ?>
                            <div class="student-card">
                                <h3><?php echo htmlspecialchars($studentData['student_name']); ?> (Roll: <?php echo htmlspecialchars($studentData['roll_number']); ?>)</h3>
                                <table class="marks-table">
                                    <thead>
                                        <tr>
                                            <th>Subject</th>
                                            <th>Term 1</th>
                                            <th>Term 2</th>
                                            <th>Average</th>
                                            <th>Grade</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($studentData['subjects'] as $subjectId => $subjectData): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($subjectData['subject_name']); ?></td>
                                                <td>
                                                    <?php 
                                                    if (isset($subjectData['terms']['term1'])) {
                                                        echo $subjectData['terms']['term1']['marks_obtained'] . '/' . 
                                                             $subjectData['terms']['term1']['total_marks'] . 
                                                             ' (' . round($subjectData['terms']['term1']['percentage'], 1) . '%)';
                                                        echo ' <a href="#" class="edit-link" onclick="updateMark(' . $studentId . ', ' . $subjectId . ', \'term1\', ' . $subjectData['terms']['term1']['marks_obtained'] . ', ' . $subjectData['terms']['term1']['total_marks'] . ')">edit</a>';
                                                    } else {
                                                        echo 'N/A <a href="#" class="edit-link" onclick="updateMark(' . $studentId . ', ' . $subjectId . ', \'term1\', 0, 100)">add</a>';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php 
                                                    if (isset($subjectData['terms']['term2'])) {
                                                        echo $subjectData['terms']['term2']['marks_obtained'] . '/' . 
                                                             $subjectData['terms']['term2']['total_marks'] . 
                                                             ' (' . round($subjectData['terms']['term2']['percentage'], 1) . '%)';
                                                        echo ' <a href="#" class="edit-link" onclick="updateMark(' . $studentId . ', ' . $subjectId . ', \'term2\', ' . $subjectData['terms']['term2']['marks_obtained'] . ', ' . $subjectData['terms']['term2']['total_marks'] . ')">edit</a>';
                                                    } else {
                                                        echo 'N/A <a href="#" class="edit-link" onclick="updateMark(' . $studentId . ', ' . $subjectId . ', \'term2\', 0, 100)">add</a>';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    $avgPercentage = 0;
                                                    $termCount = 0;
                                                    
                                                    if (isset($subjectData['terms']['term1'])) {
                                                        $avgPercentage += $subjectData['terms']['term1']['percentage'];
                                                        $termCount++;
                                                    }
                                                    
                                                    if (isset($subjectData['terms']['term2'])) {
                                                        $avgPercentage += $subjectData['terms']['term2']['percentage'];
                                                        $termCount++;
                                                    }
                                                    
                                                    if ($termCount > 0) {
                                                        $avgPercentage = $avgPercentage / $termCount;
                                                        echo round($avgPercentage, 1) . '%';
                                                    } else {
                                                        echo 'N/A';
                                                    }
                                                    ?>
                                                </td>
                                                <td>
                                                    <?php
                                                    if ($termCount > 0) {
                                                        if ($avgPercentage >= 90) echo 'A+';
                                                        elseif ($avgPercentage >= 80) echo 'A';
                                                        elseif ($avgPercentage >= 70) echo 'B';
                                                        elseif ($avgPercentage >= 60) echo 'C';
                                                        elseif ($avgPercentage >= 50) echo 'D';
                                                        else echo 'F';
                                                    } else {
                                                        echo 'N/A';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No student results available for this class.</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="card">
                <p>You are not assigned to any classes yet.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Enter Marks Modal -->
    <div id="marksModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('marksModal')">&times;</span>
            <h2 id="marksModalTitle">Enter Marks</h2>
            <form id="marksForm">
                <input type="hidden" id="class_id" name="class_id">
                <input type="hidden" id="subject_id" name="subject_id">
                <div class="form-group">
                    <label for="total_marks">Total Marks:</label>
                    <input type="number" id="total_marks" name="total_marks" required>
                </div>
                <div id="studentsContainer"></div>
                <button type="submit" class="btn">Save Marks</button>
            </form>
        </div>
    </div>

    <!-- Upload Excel Modal -->
    <div id="uploadModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('uploadModal')">&times;</span>
            <h2>Upload Excel File</h2>
            <form id="uploadForm" enctype="multipart/form-data">
                <input type="hidden" id="upload_class_id" name="class_id">
                <input type="hidden" id="upload_subject_id" name="subject_id">
                <div class="form-group">
                    <label for="total_marks_upload">Total Marks:</label>
                    <input type="number" id="total_marks_upload" name="total_marks" required>
                </div>
                <div class="upload-area">
                    <input type="file" id="excel_file" name="excel_file" accept=".xlsx,.xls,.csv" required>
                    <p>Upload Excel/CSV file with columns: Student Name, Marks Obtained</p>
                </div>
                <button type="submit" class="btn btn-success">Upload Marks</button>
            </form>
        </div>
    </div>

    <!-- Update Mark Modal -->
    <div id="updateModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('updateModal')">&times;</span>
            <h2>Update Mark</h2>
            <form id="updateForm">
                <input type="hidden" id="update_student_id" name="student_id">
                <input type="hidden" id="update_subject_id" name="subject_id">
                <input type="hidden" id="update_term" name="term">
                <div class="form-group">
                    <label for="update_marks_obtained">Marks Obtained:</label>
                    <input type="number" id="update_marks_obtained" name="marks_obtained" required>
                </div>
                <div class="form-group">
                    <label for="update_total_marks">Total Marks:</label>
                    <input type="number" id="update_total_marks" name="total_marks" required>
                </div>
                <button type="submit" class="btn">Update Mark</button>
            </form>
        </div>
    </div>

    <?php if (!empty($finalSubjectAverages) && !empty($gradeDistribution)): ?>
    <script>
        // Bar Chart for Subject Averages
        const barCtx = document.getElementById('barChart').getContext('2d');
        const barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($finalSubjectAverages)); ?>,
                datasets: [{
                    label: 'Average Marks (%)',
                    data: <?php echo json_encode(array_values($finalSubjectAverages)); ?>,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(153, 102, 255, 0.6)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });

        // Pie Chart for Grade Distribution
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        const pieChart = new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: <?php echo json_encode(array_keys($gradeDistribution)); ?>,
                datasets: [{
                    data: <?php echo json_encode(array_values($gradeDistribution)); ?>,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.6)',
                        'rgba(75, 192, 192, 0.6)',
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(255, 159, 64, 0.6)',
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(153, 102, 255, 0.6)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            }
        });
    </script>
    <?php endif; ?>

    <script>
        function openMarksModal(classId, subjectId, className, subjectName) {
            document.getElementById('class_id').value = classId;
            document.getElementById('subject_id').value = subjectId;
            document.getElementById('marksModalTitle').textContent = `Enter Marks - ${className} - ${subjectName}`;
            loadStudents(classId);
            document.getElementById('marksModal').style.display = 'block';
        }

        function openUploadModal(classId, subjectId) {
            console.log('Opening upload modal with:', classId, subjectId);
            document.getElementById('upload_class_id').value = classId;
            document.getElementById('upload_subject_id').value = subjectId;
            document.getElementById('uploadModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function loadStudents(classId) {
            fetch(`get_students.php?class_id=${classId}`)
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('studentsContainer');
                    container.innerHTML = '<h3>Students:</h3>';
                    
                    data.students.forEach(student => {
                        const div = document.createElement('div');
                        div.className = 'marks-grid';
                        div.innerHTML = `
                            <label>${student.fullname}</label>
                            <input type="number" name="marks[${student.student_id}]" placeholder="Marks" min="0">
                            <input type="hidden" name="student_ids[]" value="${student.student_id}">
                        `;
                        container.appendChild(div);
                    });
                });
        }

        document.getElementById('marksForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('save_marks.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('marksModal');
                    location.reload();
                }
            });
        });

        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            // Debug: log form data
            for (let [key, value] of formData.entries()) {
                console.log(key, value);
            }
            
            fetch('upload_marks.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('uploadModal');
                    location.reload();
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Upload failed. Please try again.');
            });
        });

        function updateMark(studentId, subjectId, term, currentMarks, totalMarks) {
            document.getElementById('update_student_id').value = studentId;
            document.getElementById('update_subject_id').value = subjectId;
            document.getElementById('update_term').value = term;
            document.getElementById('update_marks_obtained').value = currentMarks;
            document.getElementById('update_total_marks').value = totalMarks;
            document.getElementById('updateModal').style.display = 'block';
        }

        document.getElementById('updateForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('update_mark.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('updateModal');
                    location.reload();
                }
            });
        });

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>