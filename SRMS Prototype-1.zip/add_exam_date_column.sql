-- Add exam_date column to Result table
ALTER TABLE Result ADD COLUMN exam_date DATE DEFAULT NULL;

-- Update existing records with default dates (optional)
UPDATE Result SET exam_date = '2024-01-15' WHERE exam_term = 'term1';
UPDATE Result SET exam_date = '2024-06-15' WHERE exam_term = 'term2';