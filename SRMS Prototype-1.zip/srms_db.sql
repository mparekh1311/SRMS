CREATE DATABASE srms_db;
USE srms_db;


-- Disable foreign key checks temporarily to avoid issues during table creation,
-- especially if there are circular dependencies in a more complex schema.
SET FOREIGN_KEY_CHECKS = 0;

-- 1. School Table
-- Stores information about each school in the system.
CREATE TABLE School (
    school_id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(255) NOT NULL,
    school_address VARCHAR(255),
    -- Ensures each school name is unique
    UNIQUE (school_name)
);

-- 2. User Table
-- Stores user authentication details and roles.
-- Roles are student, teacher, principal.
CREATE TABLE User (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE, -- Ensures unique usernames across the system
    password VARCHAR(255) NOT NULL,       -- Store hashed passwords (e.g., using bcrypt in application)
    fullname VARCHAR(255) NOT NULL,
    role ENUM('student', 'teacher', 'principal') NOT NULL,
    school_id INT NOT NULL,               -- Links user to their school
    FOREIGN KEY (school_id) REFERENCES School(school_id)
);

-- 3. Class Table
-- Defines classes and divisions within each school.
CREATE TABLE Class (
    class_id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(10) NOT NULL,     -- e.g., '10', '12', 'V'
    division VARCHAR(10) NOT NULL,       -- e.g., 'A', 'B', 'Gamma'
    school_id INT NOT NULL,              -- Links class to its school
    FOREIGN KEY (school_id) REFERENCES School(school_id),
    -- Ensures each class-division combination is unique within a school
    UNIQUE (class_name, division, school_id)
);

-- 4. Subject Table
-- Defines the subjects offered by each school.
CREATE TABLE Subject (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(255) NOT NULL,
    school_id INT NOT NULL,              -- Links subject to its school
    FOREIGN KEY (school_id) REFERENCES School(school_id),
    -- Ensures each subject name is unique within a school
    UNIQUE (subject_name, school_id)
);

-- 5. Student Table
-- Stores details specific to students. Each student is also a user.
CREATE TABLE Student (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    roll_number VARCHAR(50) NOT NULL,
    user_id INT NOT NULL UNIQUE,         -- One-to-one relationship with User table (role 'student')
    class_id INT NOT NULL,               -- Links student to their class and division
    school_id INT NOT NULL,              -- Links student to their school
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id),
    FOREIGN KEY (school_id) REFERENCES School(school_id),
    -- Ensures roll number is unique within a specific class and school
    UNIQUE (roll_number, class_id, school_id)
);

-- 6. Teacher Table
-- Stores details specific to teachers. Each teacher is also a user.
CREATE TABLE Teacher (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,         -- One-to-one relationship with User table (role 'teacher')
    school_id INT NOT NULL,              -- Links teacher to their school
    FOREIGN KEY (user_id) REFERENCES User(user_id),
    FOREIGN KEY (school_id) REFERENCES School(school_id)
);

-- 7. Teacher_Class_Subject Table
-- Junction table to manage the many-to-many relationship:
-- which teacher teaches which subject in which class.
CREATE TABLE Teacher_Class_Subject (
    teacher_class_subject_id INT AUTO_INCREMENT PRIMARY KEY,
    teacher_id INT NOT NULL,
    class_id INT NOT NULL,
    subject_id INT NOT NULL,
    FOREIGN KEY (teacher_id) REFERENCES Teacher(teacher_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id),
    FOREIGN KEY (subject_id) REFERENCES Subject(subject_id),
    -- Ensures a teacher is assigned to a specific class-subject combination only once
    UNIQUE (teacher_id, class_id, subject_id)
);

-- 8. Result Table
-- Stores individual student results for each subject and exam term.
CREATE TABLE Result (
    result_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    class_id INT NOT NULL,               -- Redundant for easier querying, but helps ensure context
    subject_id INT NOT NULL,
    exam_term ENUM('term1', 'term2') NOT NULL,
    marks_obtained DECIMAL(5, 2) NOT NULL CHECK (marks_obtained >= 0), -- Marks cannot be negative
    total_subject_marks DECIMAL(5, 2) NOT NULL CHECK (total_subject_marks > 0), -- Total marks must be positive
    recorded_by_teacher_id INT,          -- Tracks which teacher recorded the result
    recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES Student(student_id),
    FOREIGN KEY (class_id) REFERENCES Class(class_id),
    FOREIGN KEY (subject_id) REFERENCES Subject(subject_id),
    FOREIGN KEY (recorded_by_teacher_id) REFERENCES Teacher(teacher_id),
    -- Ensures a student has only one result for a specific subject in a specific exam term
    UNIQUE (student_id, class_id, subject_id, exam_term)
);

-- Re-enable foreign key checks after all tables are created
SET FOREIGN_KEY_CHECKS = 1;




INSERT INTO School (school_name, school_address) VALUES
('Delhi Public School, Hyderabad', 'Road No. 12, Banjara Hills, Hyderabad, Telangana'),
('Kendriya Vidyalaya, Bangalore', 'Old Airport Road, Vimanapura, Bangalore, Karnataka'),
('St. Xavier\'s Collegiate School, Kolkata', '30 Park Street, Kolkata, West Bengal');

-- 2. User Table Data
-- Principals (user_id 1-3)
INSERT INTO User (username, password, fullname, role, school_id) VALUES
('priya.principal', 'principalpass123', 'Dr. Priya Sharma', 'principal', 1), -- DPS Hyderabad
('sanjay.principal', 'principalpass123', 'Mr. Sanjay Kumar', 'principal', 2), -- KV Bangalore
('thomas.principal', 'principalpass123', 'Fr. Thomas Varghese', 'principal', 3); -- St. Xavier's Kolkata

-- Teachers (user_id 4-7)
INSERT INTO User (username, password, fullname, role, school_id) VALUES
('anita.math', 'teacherpass123', 'Ms. Anita Reddy', 'teacher', 1),  -- DPS Hyderabad Math
('rajesh.sci', 'teacherpass123', 'Mr. Rajesh Singh', 'teacher', 1), -- DPS Hyderabad Science
('pooja.eng', 'teacherpass123', 'Ms. Pooja Gupta', 'teacher', 2),  -- KV Bangalore English
('amit.hist', 'teacherpass123', 'Mr. Amit Verma', 'teacher', 3);   -- St. Xavier's Kolkata History

-- Students (user_id 8-13)
INSERT INTO User (username, password, fullname, role, school_id) VALUES
('arjun.dps', 'studentpass123', 'Arjun Singh', 'student', 1),    -- DPS Hyderabad
('riya.dps', 'studentpass123', 'Riya Sharma', 'student', 1),     -- DPS Hyderabad
('kiran.kv', 'studentpass123', 'Kiran Rao', 'student', 2),      -- KV Bangalore
('sara.kv', 'studentpass123', 'Sara Khan', 'student', 2),       -- KV Bangalore
('vivek.sx', 'studentpass123', 'Vivek Das', 'student', 3),      -- St. Xavier's Kolkata
('isha.sx', 'studentpass123', 'Isha Bose', 'student', 3);       -- St. Xavier's Kolkata

-- 3. Class Table Data
INSERT INTO Class (class_name, division, school_id) VALUES
('10', 'A', 1), -- class_id 1: DPS Hyderabad Class 10A
('10', 'B', 1), -- class_id 2: DPS Hyderabad Class 10B
('9', 'A', 2),  -- class_id 3: KV Bangalore Class 9A
('9', 'B', 2),  -- class_id 4: KV Bangalore Class 9B
('11', 'Science', 3), -- class_id 5: St. Xavier's Kolkata Class 11 Science
('11', 'Commerce', 3); -- class_id 6: St. Xavier's Kolkata Class 11 Commerce

-- 4. Subject Table Data
INSERT INTO Subject (subject_name, school_id) VALUES
('Mathematics', 1), -- subject_id 1: DPS Hyderabad
('Science', 1),     -- subject_id 2: DPS Hyderabad
('English', 1),     -- subject_id 3: DPS Hyderabad
('Social Science', 1), -- subject_id 4: DPS Hyderabad
('Hindi', 2),       -- subject_id 5: KV Bangalore
('English', 2),     -- subject_id 6: KV Bangalore
('Mathematics', 2), -- subject_id 7: KV Bangalore
('Physics', 3),     -- subject_id 8: St. Xavier's Kolkata
('Chemistry', 3),   -- subject_id 9: St. Xavier's Kolkata
('Biology', 3),     -- subject_id 10: St. Xavier's Kolkata
('History', 3);     -- subject_id 11: St. Xavier's Kolkata

-- 5. Student Table Data
INSERT INTO Student (roll_number, user_id, class_id, school_id) VALUES
('23001', 8, 1, 1),  -- student_id 1: Arjun Singh (User ID 8), Class 10A (ID 1), DPS Hyd (ID 1)
('23002', 9, 1, 1),  -- student_id 2: Riya Sharma (User ID 9), Class 10A (ID 1), DPS Hyd (ID 1)
('24001', 10, 3, 2), -- student_id 3: Kiran Rao (User ID 10), Class 9A (ID 3), KV Bng (ID 2)
('24002', 11, 3, 2), -- student_id 4: Sara Khan (User ID 11), Class 9A (ID 3), KV Bng (ID 2)
('22001', 12, 5, 3), -- student_id 5: Vivek Das (User ID 12), Class 11 Science (ID 5), St. Xavier\'s Kol (ID 3)
('22002', 13, 5, 3); -- student_id 6: Isha Bose (User ID 13), Class 11 Science (ID 5), St. Xavier\'s Kol (ID 3)

-- 6. Teacher Table Data
INSERT INTO Teacher (user_id, school_id) VALUES
(4, 1), -- teacher_id 1: Ms. Anita Reddy (User ID 4), DPS Hyderabad
(5, 1), -- teacher_id 2: Mr. Rajesh Singh (User ID 5), DPS Hyderabad
(6, 2), -- teacher_id 3: Ms. Pooja Gupta (User ID 6), KV Bangalore
(7, 3); -- teacher_id 4: Mr. Amit Verma (User ID 7), St. Xavier's Kolkata

-- 7. Teacher_Class_Subject Table Data
INSERT INTO Teacher_Class_Subject (teacher_id, class_id, subject_id) VALUES
(1, 1, 1), -- Anita (Teacher ID 1) teaches Math (Sub ID 1) to DPS 10A (Class ID 1)
(1, 2, 1), -- Anita (Teacher ID 1) teaches Math (Sub ID 1) to DPS 10B (Class ID 2)
(2, 1, 2), -- Rajesh (Teacher ID 2) teaches Science (Sub ID 2) to DPS 10A (Class ID 1)
(2, 2, 2), -- Rajesh (Teacher ID 2) teaches Science (Sub ID 2) to DPS 10B (Class ID 2)
(3, 3, 5), -- Pooja (Teacher ID 3) teaches Hindi (Sub ID 5) to KV 9A (Class ID 3)
(3, 4, 6), -- Pooja (Teacher ID 3) teaches English (Sub ID 6) to KV 9B (Class ID 4)
(4, 5, 11); -- Amit (Teacher ID 4) teaches History (Sub ID 11) to SX 11 Science (Class ID 5)

-- 8. Result Table Data
-- Results for Arjun Singh (Student ID 1, Class ID 1, DPS Hyderabad)
INSERT INTO Result (student_id, class_id, subject_id, exam_term, marks_obtained, total_subject_marks, recorded_by_teacher_id) VALUES
(1, 1, 1, 'term1', 85.00, 100.00, 1), -- Arjun, Class 10A, Math, Term1 (by Anita)
(1, 1, 2, 'term1', 78.50, 100.00, 2), -- Arjun, Class 10A, Science, Term1 (by Rajesh)
(1, 1, 3, 'term1', 92.00, 100.00, 1), -- Arjun, Class 10A, English, Term1 (by Anita)
(1, 1, 1, 'term2', 90.00, 100.00, 1), -- Arjun, Class 10A, Math, Term2 (by Anita)
(1, 1, 2, 'term2', 88.00, 100.00, 2); -- Arjun, Class 10A, Science, Term2 (by Rajesh)

-- Results for Riya Sharma (Student ID 2, Class ID 1, DPS Hyderabad)
INSERT INTO Result (student_id, class_id, subject_id, exam_term, marks_obtained, total_subject_marks, recorded_by_teacher_id) VALUES
(2, 1, 1, 'term1', 90.50, 100.00, 1), -- Riya, Class 10A, Math, Term1 (by Anita)
(2, 1, 2, 'term1', 82.00, 100.00, 2), -- Riya, Class 10A, Science, Term1 (by Rajesh)
(2, 1, 1, 'term2', 95.00, 100.00, 1); -- Riya, Class 10A, Math, Term2 (by Anita)

-- Results for Kiran Rao (Student ID 3, Class ID 3, KV Bangalore)
INSERT INTO Result (student_id, class_id, subject_id, exam_term, marks_obtained, total_subject_marks, recorded_by_teacher_id) VALUES
(3, 3, 5, 'term1', 70.00, 80.00, 3), -- Kiran, Class 9A, Hindi, Term1 (by Pooja)
(3, 3, 6, 'term1', 65.00, 80.00, 3); -- Kiran, Class 9A, English, Term1 (by Pooja)

-- Results for Vivek Das (Student ID 5, Class ID 5, St. Xavier's Kolkata)
INSERT INTO Result (student_id, class_id, subject_id, exam_term, marks_obtained, total_subject_marks, recorded_by_teacher_id) VALUES
(5, 5, 8, 'term1', 75.00, 100.00, 4), -- Vivek, Class 11 Science, Physics, Term1 (by Amit)
(5, 5, 9, 'term1', 68.00, 100.00, 4); -- Vivek, Class 11 Science, Chemistry, Term1 (by Amit)

-- Execute this SQL query in your MySQL client to alter the User table
ALTER TABLE User MODIFY COLUMN role ENUM('student', 'teacher', 'principal', 'admin') NOT NULL;


-- Insert an Admin User (replace with your generated hash)
INSERT INTO User (username, password, fullname, role, school_id) VALUES
('srms.admin', 'admin', 'SRMS Administrator', 'admin', 1);
-- Note: 'school_id' for admin might be arbitrary (e.g., 1).
-- In a real multi-school system, an admin might not be tied to a specific school_id,
-- or school_id 0 could be a special value if you change the schema to allow NULL.
-- For now, link to school_id 1 as it's NOT NULL.