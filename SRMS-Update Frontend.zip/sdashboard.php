<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username']) || $_SESSION['user_type'] !== 'student') {
    header("Location: login.php");
    exit();
}

// Sample student marks data (in a real app, this would come from a database)
$studentMarks = [
    'Math' => 85,
    'Science' => 92,
    'English' => 78,
    'History' => 88,
    'Computer Science' => 95
];

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #2563eb;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #2563eb;
        }
        .container {
            max-width: 1000px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .welcome-banner {
            background: #2563eb;
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        h1, h2, h3 {
            margin-bottom: 1rem;
        }
        .marks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        .marks-table th, .marks-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .marks-table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .logout-btn {
            background: transparent;
            border: 1px solid #e5e7eb;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #333;
            text-decoration: none;
        }
        .logout-btn:hover {
            background: #f3f4f6;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="index.html">Home</a></li>
            <li><a href="logout.php" class="logout-btn">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="welcome-banner">
            <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
            <p>View your academic performance and results.</p>
        </div>

        <div class="card">
            <h2>Your Marks</h2>
            <table class="marks-table">
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Marks</th>
                        <th>Grade</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($studentMarks as $subject => $mark): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($subject); ?></td>
                            <td><?php echo $mark; ?></td>
                            <td>
                                <?php
                                if ($mark >= 90) echo 'A+';
                                elseif ($mark >= 80) echo 'A';
                                elseif ($mark >= 70) echo 'B';
                                elseif ($mark >= 60) echo 'C';
                                elseif ($mark >= 50) echo 'D';
                                else echo 'F';
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>