<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $className = trim($_POST['class_name']);
    $division = trim($_POST['division']);
    $schoolId = $_SESSION['school_id'];
    
    try {
        // Check if class already exists
        $checkQuery = "SELECT class_id FROM Class WHERE school_id = ? AND class_name = ? AND division = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("iss", $schoolId, $className, $division);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $response['message'] = 'Class already exists!';
        } else {
            // Insert new class
            $insertQuery = "INSERT INTO Class (school_id, class_name, division) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("iss", $schoolId, $className, $division);
            $stmt->execute();
            
            $response['success'] = true;
            $response['message'] = 'Class added successfully!';
        }
        
    } catch (Exception $e) {
        $response['message'] = 'Error adding class: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>