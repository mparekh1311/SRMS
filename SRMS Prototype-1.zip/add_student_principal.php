<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $rollNumber = trim($_POST['roll_number']);
    $classId = $_POST['class_id'];
    $schoolId = $_SESSION['school_id'];
    
    $username = $email;
    $password = 'student123'; // Default password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    try {
        $conn->begin_transaction();
        
        // Insert into User table
        $userQuery = "INSERT INTO User (username, password, fullname, role, school_id) VALUES (?, ?, ?, 'student', ?)";
        $stmt = $conn->prepare($userQuery);
        $stmt->bind_param("sssi", $username, $hashedPassword, $fullname, $schoolId);
        $stmt->execute();
        $userId = $conn->insert_id;
        
        // Insert into Student table
        $studentQuery = "INSERT INTO Student (roll_number, user_id, class_id, school_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($studentQuery);
        $stmt->bind_param("siii", $rollNumber, $userId, $classId, $schoolId);
        $stmt->execute();
        
        $conn->commit();
        
        $response['success'] = true;
        $response['message'] = 'Student added successfully!';
        
    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = 'Error adding student: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>