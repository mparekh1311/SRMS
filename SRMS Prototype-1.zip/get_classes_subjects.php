<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    http_response_code(403);
    exit();
}

$schoolId = $_SESSION['school_id'];

$classesQuery = "SELECT class_id, class_name, division FROM Class WHERE school_id = ? ORDER BY class_name, division";
$stmt = $conn->prepare($classesQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$result = $stmt->get_result();

$classes = [];
while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}

// Get subjects for this school
$subjectsQuery = "SELECT subject_id, subject_name FROM Subject WHERE school_id = ? ORDER BY subject_name";
$stmt = $conn->prepare($subjectsQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$subjectsResult = $stmt->get_result();

$subjects = [];
while ($row = $subjectsResult->fetch_assoc()) {
    $subjects[] = $row;
}

header('Content-Type: application/json');
echo json_encode(['classes' => $classes, 'subjects' => $subjects]);
?>