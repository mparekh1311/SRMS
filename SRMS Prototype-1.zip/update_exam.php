<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $examId = $_POST['exam_id'];
    $examDate = $_POST['exam_date'];
    $totalMarks = $_POST['total_marks'];
    
    try {
        // Update exam in Exam table
        $updateQuery = "UPDATE Exam SET exam_date = ?, total_marks = ? WHERE exam_id = ? AND school_id = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("sdii", $examDate, $totalMarks, $examId, $_SESSION['school_id']);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            $response['success'] = true;
            $response['message'] = 'Exam updated successfully!';
        } else {
            $response['message'] = 'No exam found to update.';
        }
        
    } catch (Exception $e) {
        $response['message'] = 'Error updating exam: ' . $e->getMessage();
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>