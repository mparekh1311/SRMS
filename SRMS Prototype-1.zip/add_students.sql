-- Add more students with correct user_ids (starting from 15)
INSERT INTO User (username, password, fullname, role, school_id) VALUES
('amit.dps2', 'studentpass123', 'Amit Patel', 'student', 1),
('neha.dps2', 'studentpass123', 'Neha Gupta', 'student', 1),
('raj.kv2', 'studentpass123', 'Raj Kumar', 'student', 2),
('priya.kv2', 'studentpass123', 'Priya Singh', 'student', 2),
('rohit.sx2', 'studentpass123', 'Rohit Das', 'student', 3),
('kavya.sx2', 'studentpass123', 'Kavya Bose', 'student', 3);

-- Add corresponding Student records (assuming roll numbers and class assignments)
INSERT INTO Student (roll_number, user_id, class_id, school_id) VALUES
('23003', 15, 1, 1),  -- Amit Patel (User ID 15), Class 10A (ID 1), DPS Hyd (ID 1)
('23004', 16, 2, 1),  -- Neha Gupta (User ID 16), Class 10B (ID 2), DPS Hyd (ID 1)
('24003', 17, 3, 2),  -- Raj Kumar (User ID 17), Class 9A (ID 3), KV Bng (ID 2)
('24004', 18, 4, 2),  -- Priya Singh (User ID 18), Class 9B (ID 4), KV Bng (ID 2)
('22003', 19, 5, 3),  -- Rohit Das (User ID 19), Class 11 Science (ID 5), St. Xavier's Kol (ID 3)
('22004', 20, 6, 3);  -- Kavya Bose (User ID 20), Class 11 Commerce (ID 6), St. Xavier's Kol (ID 3)