<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    header("Location: login.php");
    exit();
}

$schoolId = $_SESSION['school_id'];

// Get students for this school
$studentsQuery = "
    SELECT s.student_id, s.roll_number, u.fullname, c.class_name, c.division
    FROM Student s
    JOIN User u ON s.user_id = u.user_id
    JOIN Class c ON s.class_id = c.class_id
    WHERE s.school_id = ?
    ORDER BY c.class_name, c.division, s.roll_number
";
$stmt = $conn->prepare($studentsQuery);
$stmt->bind_param("i", $schoolId);
$stmt->execute();
$studentsResult = $stmt->get_result();

$username = $_SESSION['fullname'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students - SRMS</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: #f9fafc;
            color: #333;
            padding-top: 80px;
        }
        .navbar {
            position: fixed;
            width: 100%;
            top: 0;
            background: rgba(255,255,255,0.9);
            backdrop-filter: blur(8px);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        .logo {
            font-weight: 700;
            font-size: 1.5rem;
            color: #4338ca;
        }
        .nav-links {
            display: flex;
            gap: 1.5rem;
            list-style: none;
        }
        .nav-links a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        .nav-links a:hover {
            color: #4338ca;
        }
        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .page-header {
            background: linear-gradient(135deg, #4338ca, #6366f1);
            color: white;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 1.5rem;
        }
        .btn {
            display: inline-block;
            background: #4338ca;
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
            transition: background 0.3s ease;
            margin: 0.25rem;
        }
        .btn:hover {
            background: #3730a3;
        }
        .btn-white {
            background: white;
            color: #4338ca;
        }
        .btn-danger {
            background: #dc2626;
        }
        .btn-danger:hover {
            background: #b91c1c;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
        }
        .table th, .table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }
        .table th {
            background-color: #f3f4f6;
            font-weight: 600;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 2rem;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 1rem;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: black;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">🎓 SRMS</div>
        <ul class="nav-links">
            <li><a href="pdashboard.php">Dashboard</a></li>
            <li><a href="manage_students_principal.php">Students</a></li>
            <li><a href="manage_exams.php">Exams</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>

    <div class="container">
        <div class="page-header">
            <div>
                <h1>Manage Students</h1>
                <p>Add and manage students in your school</p>
            </div>
            <div>
                <button class="btn btn-white" onclick="openModal('studentModal')">Add Student</button>
            </div>
        </div>

        <div class="card">
            <h2>Students List</h2>
            <table class="table">
                <thead>
                    <tr>
                        <th>Roll Number</th>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($student = $studentsResult->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                            <td><?php echo htmlspecialchars($student['fullname']); ?></td>
                            <td><?php echo htmlspecialchars($student['class_name'] . ' ' . $student['division']); ?></td>
                            <td>
                                <button class="btn btn-danger" onclick="deleteStudent(<?php echo $student['student_id']; ?>)">Delete</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Student Modal -->
    <div id="studentModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('studentModal')">&times;</span>
            <h2>Add New Student</h2>
            <form id="studentForm">
                <div class="form-group">
                    <label for="fullname">Full Name:</label>
                    <input type="text" id="fullname" name="fullname" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="roll_number">Roll Number:</label>
                    <input type="text" id="roll_number" name="roll_number" required>
                </div>
                <div class="form-group">
                    <label for="class_id">Class:</label>
                    <select id="class_id" name="class_id" required>
                    </select>
                </div>
                <button type="submit" class="btn">Add Student</button>
            </form>
        </div>
    </div>

    <!-- Add Class Modal -->
    <div id="classModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('classModal')">&times;</span>
            <h2>Add New Class</h2>
            <form id="classForm">
                <div class="form-group">
                    <label for="class_name">Class/Standard:</label>
                    <input type="text" id="class_name" name="class_name" placeholder="e.g., 10, 11, 12" required>
                </div>
                <div class="form-group">
                    <label for="division">Division:</label>
                    <input type="text" id="division" name="division" placeholder="e.g., A, B, Science" required>
                </div>
                <button type="submit" class="btn">Add Class</button>
            </form>
        </div>
    </div>

    <script>
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
            if (modalId === 'studentModal') {
                loadClasses();
            }
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function loadClasses() {
            fetch('get_classes_subjects.php')
            .then(response => response.json())
            .then(data => {
                const classSelect = document.getElementById('class_id');
                classSelect.innerHTML = '<option value="">Select Class</option>';
                
                data.classes.forEach(cls => {
                    const option = document.createElement('option');
                    option.value = cls.class_id;
                    option.textContent = cls.class_name + ' ' + cls.division;
                    classSelect.appendChild(option);
                });
            });
        }

        document.getElementById('studentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('add_student_principal.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('studentModal');
                    location.reload();
                }
            });
        });

        document.getElementById('classForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            
            fetch('add_class_principal.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                if (data.success) {
                    closeModal('classModal');
                    loadClasses();
                }
            });
        });

        function deleteStudent(studentId) {
            if (confirm('Are you sure you want to delete this student?')) {
                const formData = new FormData();
                formData.append('student_id', studentId);
                
                fetch('delete_student.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.success) {
                        location.reload();
                    }
                });
            }
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>