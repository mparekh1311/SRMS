<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$classId = intval($_GET['class_id'] ?? 0);

if (empty($classId)) {
    echo json_encode(['success' => false, 'message' => 'Class ID required']);
    exit;
}

try {
    $stmt = $conn->prepare("
        SELECT s.student_id, u.fullname, s.roll_number 
        FROM Student s 
        JOIN User u ON s.user_id = u.user_id 
        WHERE s.class_id = ? 
        ORDER BY u.fullname
    ");
    $stmt->bind_param("i", $classId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
    
    echo json_encode($students);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>