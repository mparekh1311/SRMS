<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'principal') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

try {
    $className = trim($_POST['class_name']);
    $division = trim($_POST['division']);
    
    if (empty($className) || empty($division)) {
        throw new Exception('Class name and division are required');
    }
    
    // Check if class already exists
    $checkStmt = $conn->prepare("SELECT class_id FROM Class WHERE class_name = ? AND division = ? AND school_id = ?");
    $checkStmt->bind_param("ssi", $className, $division, $_SESSION['school_id']);
    $checkStmt->execute();
    
    if ($checkStmt->get_result()->num_rows > 0) {
        throw new Exception('Class with this name and division already exists');
    }
    
    // Insert new class
    $stmt = $conn->prepare("INSERT INTO Class (class_name, division, school_id) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $className, $division, $_SESSION['school_id']);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Class added successfully']);
    } else {
        throw new Exception('Failed to add class');
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>